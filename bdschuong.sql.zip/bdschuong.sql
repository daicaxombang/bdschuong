-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 31, 2021 at 10:57 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bdschuong`
--

-- --------------------------------------------------------

--
-- Table structure for table `db_accounts`
--

CREATE TABLE `db_accounts` (
  `id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `role` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `theme` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_accounts`
--

INSERT INTO `db_accounts` (`id`, `group_id`, `name`, `email`, `password`, `status`, `role`, `created`, `modified`, `theme`) VALUES
(1, 0, 'admin', 'duycuong7640@yahoo.com.vn', '0192023a7bbd73250516f069df18b500', NULL, NULL, '2013-02-18 00:00:00', '2019-10-17 15:06:12', 'red');

-- --------------------------------------------------------

--
-- Table structure for table `db_addimgs`
--

CREATE TABLE `db_addimgs` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `images` varchar(80) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `status` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_addimgs`
--

INSERT INTO `db_addimgs` (`id`, `product_id`, `images`, `name`, `created`, `status`) VALUES
(1, 1, NULL, '', '2014-10-24 09:33:25', 1),
(2, 2, NULL, '', '2014-10-24 09:34:09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_catalogues`
--

CREATE TABLE `db_catalogues` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `link` varchar(280) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  `content` text,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `order` int(10) DEFAULT NULL,
  `title_seo` varchar(500) DEFAULT NULL,
  `meta_key` varchar(500) DEFAULT NULL,
  `meta_des` varchar(500) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `type` varchar(24) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `db_catproducts`
--

CREATE TABLE `db_catproducts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(80) DEFAULT NULL,
  `link` varchar(280) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  `images1` varchar(255) DEFAULT NULL,
  `content` text,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `status1` int(11) DEFAULT '0',
  `order` int(10) DEFAULT NULL,
  `title_seo` varchar(500) DEFAULT NULL,
  `meta_key` varchar(500) DEFAULT NULL,
  `meta_des` varchar(500) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `type` varchar(24) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `linkdow` text,
  `name_eng` varchar(255) DEFAULT NULL,
  `home` int(11) DEFAULT '0',
  `home1` int(1) DEFAULT '0',
  `dang1` int(11) DEFAULT '0',
  `dang2` int(11) DEFAULT '0',
  `dang3` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `user_id_edit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_catproducts`
--

INSERT INTO `db_catproducts` (`id`, `name`, `price`, `link`, `parent_id`, `alias`, `images`, `images1`, `content`, `lft`, `rght`, `status`, `status1`, `order`, `title_seo`, `meta_key`, `meta_des`, `created`, `modified`, `type`, `url`, `linkdow`, `name_eng`, `home`, `home1`, `dang1`, `dang2`, `dang3`, `user_id`, `user_id_edit`) VALUES
(1, 'Trang chủ', NULL, 'trang-chu', NULL, NULL, NULL, NULL, '', 1, 2, 1, 0, 0, '', '', '', '2019-07-30 10:59:07', '2019-10-17 15:09:22', '', 'trang-chu', NULL, NULL, 0, 0, 0, 0, 0, 1, NULL),
(2, 'Giới thiệu', NULL, 'gioi-thieu', NULL, NULL, NULL, NULL, '', 3, 4, 1, 0, 1, '', '', '', '2019-07-30 10:59:15', '2019-10-17 15:13:29', 'new', 'gioi-thieu', NULL, NULL, 0, 0, 0, 0, 0, 1, NULL),
(4, 'Tin tức', NULL, 'tin-tuc', NULL, NULL, NULL, NULL, '', 5, 6, 1, 0, 3, '', '', '', '2019-07-30 10:59:30', '2019-10-17 15:13:29', 'new', 'tin-tuc', NULL, NULL, 0, 0, 0, 0, 0, 1, NULL),
(5, 'Đại lý', NULL, 'dai-ly', NULL, NULL, NULL, NULL, '', 7, 8, 1, 0, 4, '', '', '', '2019-07-30 10:59:41', '2019-10-17 15:13:29', 'new', 'dai-ly', NULL, NULL, 0, 0, 0, 0, 0, 1, NULL),
(6, 'Liên hệ', NULL, 'lien-he', NULL, NULL, NULL, NULL, '', 9, 10, 1, 0, 5, '', '', '', '2019-07-30 10:59:46', '2019-10-17 15:09:22', '', 'lien-he', NULL, NULL, 0, 0, 0, 0, 0, 1, NULL),
(7, 'Tin công nghệ', '', 'tin-cong-nghe', NULL, NULL, NULL, NULL, '', 11, 12, 1, 0, 5, '', '', '', '2019-08-01 22:12:18', '2019-10-17 15:13:29', 'new', 'tin-cong-nghe', NULL, NULL, 0, 0, 0, 0, 0, 1, NULL),
(8, 'Sản phẩm', NULL, 'san-pham', NULL, NULL, NULL, NULL, '', 13, 20, 1, 0, 2, '', '', '', '2019-08-02 10:19:23', '2019-11-04 11:15:40', 'product', 'brictec-viet-nam', NULL, NULL, 0, 0, 0, 0, 0, 1, 1),
(9, 'máy sản xuất gạch', NULL, 'may-san-xuat-gach', 8, NULL, NULL, NULL, '', 14, 15, 1, 0, 3, '', '', '', '2019-10-17 14:40:49', '2019-11-04 11:18:16', 'product', 'brictec-viet-nam', NULL, NULL, 0, 0, 0, 0, 0, 1, 1),
(10, 'máy ép khung bản', NULL, 'may-ep-khung-ban', 8, NULL, NULL, NULL, '', 16, 17, 1, 0, 4, '', '', '', '2019-11-04 11:18:30', '2019-11-04 11:18:30', 'product', 'brictec-viet-nam', NULL, NULL, 0, 0, 0, 0, 0, 1, NULL),
(11, 'pin năng lượng mặt trời', NULL, 'pin-nang-luong-mat-troi', 8, NULL, NULL, NULL, '', 18, 19, 1, 0, 5, '', '', '', '2019-11-04 11:18:43', '2019-11-04 11:18:43', 'product', 'brictec-viet-nam', NULL, NULL, 0, 0, 0, 0, 0, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_emaildks`
--

CREATE TABLE `db_emaildks` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `cread` datetime DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_emaildks`
--

INSERT INTO `db_emaildks` (`id`, `email`, `cread`, `lft`, `rght`) VALUES
(1, 'duytien123@gmail.com', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_extentions`
--

CREATE TABLE `db_extentions` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `name1` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  `images2` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `url1` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `type` varchar(24) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_id_edit` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_extentions`
--

INSERT INTO `db_extentions` (`id`, `name`, `name1`, `images`, `images2`, `url`, `url1`, `created`, `modified`, `status`, `type`, `order`, `user_id`, `user_id_edit`) VALUES
(59, NULL, NULL, 'c9ce8b01-94be-4c09-828b-3e63cf571108.jpeg', NULL, NULL, NULL, '2019-08-02 10:09:22', '2019-10-17 15:05:36', 1, 'banner', NULL, NULL, NULL),
(52, '', NULL, 'img-qc.png', NULL, '', NULL, '2016-03-15 17:27:21', '2016-03-15 17:27:21', 1, 'advthree', 0, 1, NULL),
(51, '', NULL, 'benh-da-day-2.png', NULL, '', NULL, '2016-03-04 15:46:40', '2016-03-04 15:46:40', 1, 'righttwo', 0, 1, NULL),
(13, '', NULL, 'r1-4.png', NULL, '', NULL, '2014-12-08 16:43:30', '2014-12-08 16:43:30', 1, 'advvideo', 0, 1, NULL),
(76, '', NULL, 'vhs-hotline-bn.jpeg', NULL, '', NULL, '2021-07-31 17:03:07', '2021-07-31 17:03:07', 1, 'rightone', 0, 1, NULL),
(26, NULL, NULL, 'logo.png', NULL, NULL, NULL, '2015-05-15 16:36:42', '2015-05-15 16:36:42', 1, 'logo', NULL, NULL, NULL),
(53, '', NULL, 'banner1.png', NULL, '', NULL, '2016-04-21 17:15:33', '2016-04-21 17:15:33', 1, 'advone', 0, 1, NULL),
(54, '', NULL, 'banner1-2.png', NULL, '', NULL, '2016-04-21 17:15:42', '2016-04-21 17:15:42', 1, 'advtwo', 0, 1, NULL),
(62, '', NULL, 'ec503b78-a5e6-4e31-835b-9aac93fcb9b6.jpeg', NULL, '', NULL, '2019-08-02 10:26:50', '2019-11-17 09:06:46', 1, 'advright', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_exttmps`
--

CREATE TABLE `db_exttmps` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_id_edit` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_exttmps`
--

INSERT INTO `db_exttmps` (`id`, `name`, `order`, `type`, `status`, `created`, `modified`, `user_id`, `user_id_edit`, `lft`, `rght`) VALUES
(1, 'S', 0, 'size', 1, '2016-06-23 08:52:33', '2016-06-23 08:52:33', 1, NULL, NULL, NULL),
(2, 'M', 1, 'size', 1, '2016-06-23 08:52:37', '2016-06-23 08:52:37', 1, NULL, NULL, NULL),
(3, 'L', 2, 'size', 1, '2016-06-23 08:52:40', '2016-06-23 08:52:40', 1, NULL, NULL, NULL),
(4, 'XL', 3, 'size', 1, '2016-06-23 08:52:51', '2016-06-23 08:52:51', 1, NULL, NULL, NULL),
(5, 'XXL', 4, 'size', 1, '2016-06-23 08:52:55', '2016-06-23 08:52:55', 1, NULL, NULL, NULL),
(6, 'Xanh', 0, 'color', 1, '2016-06-23 08:55:07', '2016-06-23 08:55:07', 1, NULL, NULL, NULL),
(7, 'Đỏ', 1, 'color', 1, '2016-06-23 08:55:11', '2016-06-23 08:55:11', 1, NULL, NULL, NULL),
(8, 'Trắng', 2, 'color', 1, '2016-06-23 08:55:16', '2016-06-23 08:55:16', 1, NULL, NULL, NULL),
(9, 'Ghi', 3, 'color', 1, '2016-06-23 08:55:20', '2016-06-23 08:55:20', 1, NULL, NULL, NULL),
(10, 'Tím than', 4, 'color', 1, '2016-06-23 08:55:25', '2016-06-23 08:55:25', 1, NULL, NULL, NULL),
(11, 'Đen', 5, 'color', 1, '2016-06-23 08:55:29', '2016-06-23 08:55:29', 1, NULL, NULL, NULL),
(12, 'Vàng', 6, 'color', 1, '2016-06-23 08:55:34', '2016-06-23 08:55:34', 1, NULL, NULL, NULL),
(13, 'Nâu', 7, 'color', 1, '2016-06-23 08:55:38', '2016-06-23 08:55:38', 1, NULL, NULL, NULL),
(14, 'Xanh lá', 8, 'color', 1, '2016-06-23 15:18:56', '2016-06-23 15:18:56', 1, NULL, NULL, NULL),
(15, 'Hồng', 9, 'color', 1, '2016-06-23 15:19:00', '2016-06-23 15:19:00', 1, NULL, NULL, NULL),
(16, 'Xanh dương', 10, 'color', 1, '2016-06-23 15:19:05', '2016-06-23 15:19:05', 1, NULL, NULL, NULL),
(17, 'Tím', 4, 'color', 1, '2016-06-23 15:19:17', '2016-06-23 15:19:17', NULL, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_groups`
--

CREATE TABLE `db_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `permision` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `db_hangs`
--

CREATE TABLE `db_hangs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(80) DEFAULT NULL,
  `link` varchar(280) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  `content` text,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `order` int(10) DEFAULT NULL,
  `title_seo` varchar(500) DEFAULT NULL,
  `meta_key` varchar(500) DEFAULT NULL,
  `meta_des` varchar(500) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `type` varchar(24) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `linkdow` text,
  `name_eng` varchar(255) DEFAULT NULL,
  `home` int(11) DEFAULT '0',
  `dang1` int(11) DEFAULT '0',
  `dang2` int(11) DEFAULT '0',
  `dang3` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `user_id_edit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_hangs`
--

INSERT INTO `db_hangs` (`id`, `name`, `price`, `link`, `parent_id`, `alias`, `images`, `content`, `lft`, `rght`, `status`, `order`, `title_seo`, `meta_key`, `meta_des`, `created`, `modified`, `type`, `url`, `linkdow`, `name_eng`, `home`, `dang1`, `dang2`, `dang3`, `user_id`, `user_id_edit`) VALUES
(1, 'Apple', NULL, 'apple', NULL, NULL, 'apple.png', '', NULL, NULL, 1, 0, '', '', '', '2015-04-13 15:38:12', '2015-04-13 15:38:12', 'product', 'apple', NULL, NULL, 0, 0, 0, 0, 1, NULL),
(2, 'Sony', NULL, 'sony', NULL, NULL, 'sony.png', '', NULL, NULL, 1, 1, '', '', '', '2015-04-13 15:38:30', '2015-04-13 15:38:30', 'product', 'sony', NULL, NULL, 0, 0, 0, 0, 1, NULL),
(3, 'Samsung', NULL, 'samsung', NULL, NULL, 'samsung.png', '', NULL, NULL, 1, 2, '', '', '', '2015-04-13 15:38:38', '2015-04-13 15:38:38', 'product', 'samsung', NULL, NULL, 0, 0, 0, 0, 1, NULL),
(4, 'HTC', NULL, 'htc', NULL, NULL, 'htc.png', '', NULL, NULL, 1, 3, '', '', '', '2015-04-13 15:38:46', '2015-04-13 15:38:46', 'product', 'htc', NULL, NULL, 0, 0, 0, 0, 1, NULL),
(5, 'LG', NULL, 'lg', NULL, NULL, 'lg.png', '', NULL, NULL, 1, 4, '', '', '', '2015-04-13 15:38:53', '2015-04-13 15:38:53', 'product', 'lg', NULL, NULL, 0, 0, 0, 0, 1, NULL),
(6, 'OPPO', NULL, 'oppo', NULL, NULL, 'oppo.png', '', NULL, NULL, 1, 5, '', '', '', '2015-04-13 15:39:09', '2015-04-13 15:39:09', 'product', 'oppo', NULL, NULL, 0, 0, 0, 0, 1, NULL),
(7, 'ASUS', NULL, 'asus', NULL, NULL, 'asus.png', '', NULL, NULL, 1, 6, '', '', '', '2015-04-13 15:39:19', '2015-04-13 15:39:19', 'product', 'asus', NULL, NULL, 0, 0, 0, 0, 1, NULL),
(8, 'Blackberry', NULL, 'blackberry', NULL, NULL, 'blackberry.png', '', NULL, NULL, 1, 7, '', '', '', '2015-04-13 15:40:12', '2015-04-13 15:40:12', 'product', 'blackberry', NULL, NULL, 0, 0, 0, 0, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_infocustomers`
--

CREATE TABLE `db_infocustomers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `content` text,
  `size` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `db_kiemchuyen`
--

CREATE TABLE `db_kiemchuyen` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_kiemchuyen`
--

INSERT INTO `db_kiemchuyen` (`id`, `name`, `lft`, `rght`) VALUES
(1, 'ca', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_orders`
--

CREATE TABLE `db_orders` (
  `id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `info_id` int(11) DEFAULT NULL,
  `slg` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `db_pages`
--

CREATE TABLE `db_pages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `link` varchar(280) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  `content` text,
  `status` int(1) DEFAULT '1',
  `title_seo` varchar(500) DEFAULT NULL,
  `meta_key` varchar(500) DEFAULT NULL,
  `meta_des` varchar(500) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `position` varchar(24) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `db_permisions`
--

CREATE TABLE `db_permisions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `allow` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_permisions`
--

INSERT INTO `db_permisions` (`id`, `name`, `allow`, `status`, `created`, `modified`) VALUES
(1, 'Quyền truy cập danh mục', 'catproducts', 1, '2014-12-08 10:37:57', '2014-12-08 10:37:57'),
(2, 'Quyền truy cập danh mục - sửa', 'catproducts/edit', 1, '2014-12-08 10:38:29', '2014-12-08 10:38:29');

-- --------------------------------------------------------

--
-- Table structure for table `db_posts`
--

CREATE TABLE `db_posts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `shortdes` text,
  `content` longtext,
  `cat_id` int(11) DEFAULT NULL,
  `quote` text,
  `link` varchar(280) DEFAULT NULL,
  `multiple` text,
  `images` varchar(255) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `choose1` int(11) DEFAULT '0',
  `choose2` int(11) DEFAULT '0',
  `choose3` int(11) DEFAULT '0',
  `choose4` int(11) DEFAULT '0',
  `choose5` int(11) DEFAULT '0',
  `price` int(11) DEFAULT NULL,
  `sale_off` int(11) DEFAULT NULL,
  `view` int(11) DEFAULT '0',
  `name_eng` varchar(255) DEFAULT NULL,
  `shortdes_eng` text,
  `content_eng` text,
  `title_seo` varchar(500) DEFAULT NULL,
  `meta_key` varchar(500) DEFAULT NULL,
  `meta_des` varchar(500) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id_edit` int(11) DEFAULT NULL,
  `type` varchar(24) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `auto` int(11) DEFAULT '0',
  `diadiem` varchar(255) DEFAULT NULL,
  `mucluong` varchar(50) DEFAULT NULL,
  `thoigianthituyen` varchar(50) DEFAULT NULL,
  `hannophoso` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `traloi` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_posts`
--

INSERT INTO `db_posts` (`id`, `name`, `shortdes`, `content`, `cat_id`, `quote`, `link`, `multiple`, `images`, `order`, `user_id`, `choose1`, `choose2`, `choose3`, `choose4`, `choose5`, `price`, `sale_off`, `view`, `name_eng`, `shortdes_eng`, `content_eng`, `title_seo`, `meta_key`, `meta_des`, `created`, `modified`, `user_id_edit`, `type`, `status`, `auto`, `diadiem`, `mucluong`, `thoigianthituyen`, `hannophoso`, `email`, `phone`, `traloi`) VALUES
(10, 'Cấu tạo hệ thống lò xoay di động mới có gì đặc biệt?', '<p><span style=\"color: rgb(98, 98, 98); font-family: Arial, Arial, Tahoma, sans-serif; font-size: 14px; text-align: justify;\">Kh&oacute;i được th&ocirc;ng qua đường ống kh&oacute;i trượt đi v&agrave;o hệ thống xử l&yacute; kh&iacute; thải , nắp trượt của hệ thống v&agrave; l&ograve; di chuyển c&ugrave;ng l&uacute;c , đạt đến mức độ tiếp x&uacute;c v&ocirc; c&ugrave;ng k&iacute;n , kh&ocirc;ng bị hở , l&agrave;m cho lượng gi&oacute; trong l&ograve;ng l&ograve; lu&ocirc;n lu&ocirc;n ổn định . Sự vận h&agrave;nh hợp l&yacute; của hệ thống đưa gi&oacute; đ&agrave;o thải kh&iacute; thải , đ&atilde; l&agrave;m giảm đ&aacute;ng kể lượng đ&agrave;o thải kh&iacute; thải từ c&aacute;c thiết bị xử l&yacute; khử huỳnh , c&agrave;ng dễ d&agrave;ng c&oacute; thể đạt đến ti&ecirc;u chuẩn về bảo vệ m&ocirc;i trường .</span></p>\r\n', 'Quy trình sản xuất Gạch Tuynel\r\n 15/05/2018\r\nGạch tuynel được sản xuất theo quy trình đặc biệt với sự hỗ trợ của những phương tiện, công nghệ trang thiết bị hiện đại hoàn thành những sản phẩm gạch mẫu mã đẹp, chất lượng gạch tốt\r\n\r\nLà một trong những loại gạch xây dựng được ưa chuộng nhiều trên thị trường vật liệu gạch xây dựng qua nhiều năm, gạch tuynel với các ưu điểm về mẫu mã đẹp, màu sắc bắt mắt, chất lượng gạch tốt, độ rắn chắc cao, đồng thời tiết kiệm nhiều chi phí so với các loại gạch khác. Đặc biệt, khi máy móc, các trang bị kỹ thuật công nghệ tiên tiến ngày càng cao, quy trình sản xuất gạch tuynel cũng liên tục được cải tiến mang tới hiệu quả về cả năng suất cũng như chất lượng của sản phẩm.\r\n\r\n\r\n \r\nMột số thông tin về gạch tuynel trên thị trường hiện nay\r\nGạch tuynel được biết đến là loại gạch đất nung truyền thống có nguyên liệu chính là đất sét hoặc đất đồi, trải qua quá trình tạo hình, nung nóng trong lò nung lên tới khoảng 1000 độ C để sản xuất nên các viên gạch hoàn thiện.\r\n\r\nGạch tuynel trên thị trường hiện nay có các loại gạch kích cỡ phong phú đáp ứng nhu cầu của từng công trình xây dựng như: gạch tuynel 2 lỗ, gạch tuynel đặc, gạch tuynel 6 lỗ…\r\n\r\n\r\n\r\n \r\nQuy trình sản xuất gạch tuynel hiện nay\r\nVới sự phát triển của các trang thiết bị máy móc, công nghệ sản xuất gạch tuynel ngày nay theo dây chuyền tự động hóa theo những công đoạn tiêu chuẩn như:\r\n\r\nĐất sét hoặc đất đồi sau khi khai thác, được ngâm ủ và xử lý, loại bỏ các chất tạp theo quy định, nhằm tăng tính dẻo cũng như độ đồng đều của đất\r\n\r\nNhào trộn đất: Đất sét, đất đồi được đưa vào máy cán thô cán mịn dẻo, máy nhào trộn 2 trục cùng than cám để đạt được độ dẻo cần thiết. Khi gạch đạt được độ dẻo theo tiêu chuẩn, để tạo hình gạch, người ta sử dụng máy đùn hút chân không, từ đó đưa nguyên liệu vào khuôn để sản xuất gạch mộc đồng thời đảm bảo độ đặc, cường độ sản phẩm.\r\n\r\n \r\n\r\nSản phẩm gạch mộc được vận chuyển lên trại phơi dưới ánh nắng mặt trời, trong trường hợp điều kiện thời tiết không thuận lợi, gạch mộc sẽ được sấy khô trong lò sấy tuynel tại nhiệt độ, thời gian nhất định cho sản phẩm đạt độ khô cần thiết.\r\n\r\nGạch sau khi đảm bảo độ khô theo quy định được chuyển sang lò nung trong nhiệt độ từ 900 độc – 1000 độ C để hoàn thiện. Sản phẩm sau khi nung đạt độ cứng tiêu chuẩn, sẽ được chuyển ra khỏi lò và vận chuyển tới bãi chứa gạch tại xưởng\r\n \r\n\r\nGạch tuynel tại xưởng\r\n\r\nTrên đây là một vài thông tin cũng như quy trình sản xuất gạch tuynel. Với những ưu điểm nổi bật cũng như thích hợp với điều kiện khí hậu thời tiết tại Việt Nam, gạch tuynel đang là loại gạch xây dựng được ưa chuộng từ lâu.', 4, NULL, 'cau-tao-he-thong-lo-xoay-di-dong-moi-co-gi-dac-biet', NULL, 'cau-tao-he-thong-lo-xoay-di-dong-moi-co-gi-dac-biet.jpg', 2, 1, 0, 0, 0, NULL, 0, NULL, NULL, 17, NULL, NULL, NULL, '', '', '', '2019-08-01 21:43:02', '2021-07-30 00:56:13', 1, 'post', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `db_posts` (`id`, `name`, `shortdes`, `content`, `cat_id`, `quote`, `link`, `multiple`, `images`, `order`, `user_id`, `choose1`, `choose2`, `choose3`, `choose4`, `choose5`, `price`, `sale_off`, `view`, `name_eng`, `shortdes_eng`, `content_eng`, `title_seo`, `meta_key`, `meta_des`, `created`, `modified`, `user_id_edit`, `type`, `status`, `auto`, `diadiem`, `mucluong`, `thoigianthituyen`, `hannophoso`, `email`, `phone`, `traloi`) VALUES
(11, 'Công nghệ lò tuynel mới nhất', '<p>C&ocirc;ng nghệ l&ograve; tuynel mới nhất</p>\r\n', '<div class=\"section section-post-header\" style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Arial, Arial, Tahoma, sans-serif; vertical-align: baseline; position: relative; color: rgb(98, 98, 98);\">\r\n<div class=\"section_wrapper clearfix\" style=\"margin: 0px auto; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; max-width: calc(100% - 20px); position: relative; zoom: 1;\">\r\n<div class=\"column one post-header\" style=\"margin: 0px 9.1875px 20px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; float: left; width: 901px;\">\r\n<div class=\"title_wrapper\" style=\"margin: 0px; padding: 0px 0px 0px 10px; border-top: 0px solid; border-right: 0px solid; border-bottom: 0px solid; border-left: none; border-image: initial; font: inherit; vertical-align: baseline;\">\r\n<h1 class=\"entry-title\" itemprop=\"headline\" style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: 35px; line-height: 35px; vertical-align: baseline; color: rgb(0, 0, 0); letter-spacing: 0px;\">M&ocirc; tả quy tr&igrave;nh c&ocirc;ng nghệ sản xuất gạch tuynel theo c&ocirc;ng nghệ l&ograve; tuynel di động mới nhất</h1>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"post-wrapper-content\" style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Arial, Arial, Tahoma, sans-serif; vertical-align: baseline; color: rgb(98, 98, 98);\">\r\n<div class=\"section the_content has_content\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; position: relative;\">\r\n<div class=\"section_wrapper\" style=\"margin: 0px auto; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; max-width: calc(100% - 20px); position: relative;\">\r\n<p>&nbsp;</p>\r\n\r\n<div class=\"the_content_wrapper\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">\r\n<div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; clear: both;\">&nbsp;</div>\r\n\r\n<div class=\"the_champ_sharing_container the_champ_horizontal_sharing\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\" super-socializer-data-href=\"http://robotxepgach.com/mo-ta-quy-trinh-cong-nghe-san-xuat-gach-tuynel-theo-cong-nghe-lo-tuynel-di-dong-moi-nhat.html\">\r\n<div class=\"the_champ_sharing_title\" style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: bold; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">Spread the love</div>\r\n\r\n<ul class=\"the_champ_sharing_ul\" style=\"padding-right: 0px; border: 0px; font: inherit; vertical-align: baseline; color: rgb(115, 126, 134); margin: 1px 0px !important; padding-left: 0px !important; list-style: none !important;\">\r\n	<li class=\"theChampSharingRound\" style=\"margin: 0px !important; padding: 0px !important; border: none !important; font: inherit; vertical-align: baseline; clear: none; float: left !important; list-style: none !important; width: auto; background: 0px 0px !important;\"><i alt=\"Facebook\" class=\"theChampSharing theChampFacebookBackground\" style=\"margin: 2px; padding: 0px; border: 0px solid transparent; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; display: block; cursor: pointer; background-color: rgb(66, 103, 178); float: left; color: rgb(255, 255, 255); width: 35px; height: 35px; border-radius: 999px;\" title=\"Facebook\"><ss class=\"theChampSharingSvg theChampFacebookSvg\" style=\"width: 35px; height: 35px; background: url(&quot;data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%25%22%20height%3D%22100%25%22%20viewBox%3D%22-5%20-5%2042%2042%22%3E%3Cpath%20d%3D%22M17.78%2027.5V17.008h3.522l.527-4.09h-4.05v-2.61c0-1.182.33-1.99%202.023-1.99h2.166V4.66c-.375-.05-1.66-.16-3.155-.16-3.123%200-5.26%201.905-5.26%205.405v3.016h-3.53v4.09h3.53V27.5h4.223z%22%20fill%3D%22%23fff%22%3E%3C%2Fpath%3E%3C%2Fsvg%3E&quot;) center center no-repeat; display: block; border-radius: 999px;\"></ss></i></li>\r\n	<li class=\"theChampSharingRound\" style=\"margin: 0px !important; padding: 0px !important; border: none !important; font: inherit; vertical-align: baseline; clear: none; float: left !important; list-style: none !important; width: auto; background: 0px 0px !important;\"><i alt=\"Twitter\" class=\"theChampSharing theChampTwitterBackground\" style=\"margin: 2px; padding: 0px; border: 0px solid transparent; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; display: block; cursor: pointer; background-color: rgb(85, 172, 238); float: left; color: rgb(255, 255, 255); width: 35px; height: 35px; border-radius: 999px;\" title=\"Twitter\"><ss class=\"theChampSharingSvg theChampTwitterSvg\" style=\"width: 35px; height: 35px; background: url(&quot;data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%25%22%20height%3D%22100%25%22%20viewBox%3D%22-4%20-4%2039%2039%22%3E%0A%3Cpath%20d%3D%22M28%208.557a9.913%209.913%200%200%201-2.828.775%204.93%204.93%200%200%200%202.166-2.725%209.738%209.738%200%200%201-3.13%201.194%204.92%204.92%200%200%200-3.593-1.55%204.924%204.924%200%200%200-4.794%206.049c-4.09-.21-7.72-2.17-10.15-5.15a4.942%204.942%200%200%200-.665%202.477c0%201.71.87%203.214%202.19%204.1a4.968%204.968%200%200%201-2.23-.616v.06c0%202.39%201.7%204.38%203.952%204.83-.414.115-.85.174-1.297.174-.318%200-.626-.03-.928-.086a4.935%204.935%200%200%200%204.6%203.42%209.893%209.893%200%200%201-6.114%202.107c-.398%200-.79-.023-1.175-.068a13.953%2013.953%200%200%200%207.55%202.213c9.056%200%2014.01-7.507%2014.01-14.013%200-.213-.005-.426-.015-.637.96-.695%201.795-1.56%202.455-2.55z%22%20fill%3D%22%23fff%22%3E%3C%2Fpath%3E%0A%3C%2Fsvg%3E&quot;) center center no-repeat; display: block; border-radius: 999px;\"></ss></i></li>\r\n	<li class=\"theChampSharingRound\" style=\"margin: 0px !important; padding: 0px !important; border: none !important; font: inherit; vertical-align: baseline; clear: none; float: left !important; list-style: none !important; width: auto; background: 0px 0px !important;\"><i alt=\"Linkedin\" class=\"theChampSharing theChampLinkedinBackground\" style=\"margin: 2px; padding: 0px; border: 0px solid transparent; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; display: block; cursor: pointer; background-color: rgb(0, 119, 181); float: left; color: rgb(255, 255, 255); width: 35px; height: 35px; border-radius: 999px;\" title=\"Linkedin\"><ss class=\"theChampSharingSvg theChampLinkedinSvg\" style=\"width: 35px; height: 35px; background: url(&quot;data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%25%22%20height%3D%22100%25%22%20viewBox%3D%22-2%20-2%2035%2039%22%3E%3Cpath%20d%3D%22M6.227%2012.61h4.19v13.48h-4.19V12.61zm2.095-6.7a2.43%202.43%200%200%201%200%204.86c-1.344%200-2.428-1.09-2.428-2.43s1.084-2.43%202.428-2.43m4.72%206.7h4.02v1.84h.058c.56-1.058%201.927-2.176%203.965-2.176%204.238%200%205.02%202.792%205.02%206.42v7.395h-4.183v-6.56c0-1.564-.03-3.574-2.178-3.574-2.18%200-2.514%201.7-2.514%203.46v6.668h-4.187V12.61z%22%20fill%3D%22%23fff%22%2F%3E%3C%2Fsvg%3E&quot;) center center no-repeat; display: block; border-radius: 999px;\"></ss></i></li>\r\n	<li class=\"theChampSharingRound\" style=\"margin: 0px !important; padding: 0px !important; border: none !important; font: inherit; vertical-align: baseline; clear: none; float: left !important; list-style: none !important; width: auto; background: 0px 0px !important;\"><i alt=\"Pinterest\" class=\"theChampSharing theChampPinterestBackground\" style=\"margin: 2px; padding: 0px; border: 0px solid transparent; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; display: block; cursor: pointer; background-color: rgb(204, 35, 41); float: left; color: rgb(255, 255, 255); width: 35px; height: 35px; border-radius: 999px;\" title=\"Pinterest\"><ss class=\"theChampSharingSvg theChampPinterestSvg\" style=\"width: 35px; height: 35px; background: url(&quot;data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%25%22%20height%3D%22100%25%22%20viewBox%3D%22-2%20-2%2035%2035%22%3E%3Cpath%20fill%3D%22%23fff%22%20d%3D%22M16.539%204.5c-6.277%200-9.442%204.5-9.442%208.253%200%202.272.86%204.293%202.705%205.046.303.125.574.005.662-.33.061-.231.205-.816.27-1.06.088-.331.053-.447-.191-.736-.532-.627-.873-1.439-.873-2.591%200-3.338%202.498-6.327%206.505-6.327%203.548%200%205.497%202.168%205.497%205.062%200%203.81-1.686%207.025-4.188%207.025-1.382%200-2.416-1.142-2.085-2.545.397-1.674%201.166-3.48%201.166-4.689%200-1.081-.581-1.983-1.782-1.983-1.413%200-2.548%201.462-2.548%203.419%200%201.247.421%202.091.421%202.091l-1.699%207.199c-.505%202.137-.076%204.755-.039%205.019.021.158.223.196.314.077.13-.17%201.813-2.247%202.384-4.324.162-.587.929-3.631.929-3.631.46.876%201.801%201.646%203.227%201.646%204.247%200%207.128-3.871%207.128-9.053.003-3.918-3.317-7.568-8.361-7.568z%22%2F%3E%3C%2Fsvg%3E&quot;) center center no-repeat; display: block; border-radius: 999px;\"></ss></i></li>\r\n	<li class=\"theChampSharingRound\" style=\"margin: 0px !important; padding: 0px !important; border: none !important; font: inherit; vertical-align: baseline; clear: none; float: left !important; list-style: none !important; width: auto; background: 0px 0px !important;\"><i alt=\"Reddit\" class=\"theChampSharing theChampRedditBackground\" style=\"margin: 2px; padding: 0px; border: 0px solid transparent; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; display: block; cursor: pointer; background-color: rgb(255, 87, 0); float: left; color: rgb(255, 255, 255); width: 35px; height: 35px; border-radius: 999px;\" title=\"Reddit\"><ss class=\"theChampSharingSvg theChampRedditSvg\" style=\"width: 35px; height: 35px; background: url(&quot;data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%25%22%20height%3D%22100%25%22%20viewBox%3D%22-3.5%20-3.5%2039%2039%22%3E%3Cpath%20d%3D%22M28.543%2015.774a2.953%202.953%200%200%200-2.951-2.949%202.882%202.882%200%200%200-1.9.713%2014.075%2014.075%200%200%200-6.85-2.044l1.38-4.349%203.768.884a2.452%202.452%200%201%200%20.24-1.176l-4.274-1a.6.6%200%200%200-.709.4l-1.659%205.224a14.314%2014.314%200%200%200-7.316%202.029%202.908%202.908%200%200%200-1.872-.681%202.942%202.942%200%200%200-1.618%205.4%205.109%205.109%200%200%200-.062.765c0%204.158%205.037%207.541%2011.229%207.541s11.22-3.383%2011.22-7.541a5.2%205.2%200%200%200-.053-.706%202.963%202.963%200%200%200%201.427-2.51zm-18.008%201.88a1.753%201.753%200%200%201%201.73-1.74%201.73%201.73%200%200%201%201.709%201.74%201.709%201.709%200%200%201-1.709%201.711%201.733%201.733%200%200%201-1.73-1.711zm9.565%204.968a5.573%205.573%200%200%201-4.081%201.272h-.032a5.576%205.576%200%200%201-4.087-1.272.6.6%200%200%201%20.844-.854%204.5%204.5%200%200%200%203.238.927h.032a4.5%204.5%200%200%200%203.237-.927.6.6%200%201%201%20.844.854zm-.331-3.256a1.726%201.726%200%201%201%201.709-1.712%201.717%201.717%200%200%201-1.712%201.712z%22%20fill%3D%22%23fff%22%2F%3E%3C%2Fsvg%3E&quot;) center center no-repeat; display: block; border-radius: 999px;\"></ss></i></li>\r\n	<li class=\"theChampSharingRound\" style=\"margin: 0px !important; padding: 0px !important; border: none !important; font: inherit; vertical-align: baseline; clear: none; float: left !important; list-style: none !important; width: auto; background: 0px 0px !important;\"><i alt=\"Mix\" class=\"theChampSharing theChampMixBackground\" style=\"margin: 2px; padding: 0px; border: 0px solid transparent; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; display: block; cursor: pointer; background-color: rgb(255, 130, 38); float: left; color: rgb(255, 255, 255); width: 35px; height: 35px; border-radius: 999px;\" title=\"Mix\"><ss class=\"theChampSharingSvg theChampMixSvg\" style=\"width: 35px; height: 35px; background: url(&quot;data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%22-7%20-8%2045%2045%22%3E%3Cg%20fill%3D%22%23fff%22%3E%3Cpath%20opacity%3D%22.8%22%20d%3D%22M27.87%204.125c-5.224%200-9.467%204.159-9.467%209.291v2.89c0-1.306%201.074-2.362%202.399-2.362s2.399%201.056%202.399%202.362v1.204c0%201.306%201.074%202.362%202.399%202.362s2.399-1.056%202.399-2.362V4.134c-.036-.009-.082-.009-.129-.009%22%2F%3E%3Cpath%20d%3D%22M4%204.125v12.94c2.566%200%204.668-1.973%204.807-4.465v-2.214c0-.065%200-.12.009-.176.093-1.213%201.13-2.177%202.39-2.177%201.325%200%202.399%201.056%202.399%202.362v9.226c0%201.306%201.074%202.353%202.399%202.353s2.399-1.056%202.399-2.353v-6.206c0-5.132%204.233-9.291%209.467-9.291H4z%22%2F%3E%3Cpath%20opacity%3D%22.8%22%20d%3D%22M4%2017.074v8.438c0%201.306%201.074%202.362%202.399%202.362s2.399-1.056%202.399-2.362V12.61C8.659%2015.102%206.566%2017.074%204%2017.074%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E&quot;) center center no-repeat; display: block; border-radius: 999px;\"></ss></i></li>\r\n	<li class=\"theChampSharingRound\" style=\"margin: 0px !important; padding: 0px !important; border: none !important; font: inherit; vertical-align: baseline; clear: none; float: left !important; list-style: none !important; width: auto; background: 0px 0px !important;\"><i alt=\"Whatsapp\" class=\"theChampSharing theChampWhatsappBackground\" style=\"margin: 2px; padding: 0px; border: 0px solid transparent; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; display: block; cursor: pointer; background-color: rgb(85, 235, 76); float: left; color: rgb(255, 255, 255); width: 35px; height: 35px; border-radius: 999px;\" title=\"Whatsapp\"><a href=\"https://web.whatsapp.com/send?text=M%C3%B4%20t%E1%BA%A3%20quy%20tr%C3%ACnh%20c%C3%B4ng%20ngh%E1%BB%87%20s%E1%BA%A3n%20xu%E1%BA%A5t%20g%E1%BA%A1ch%20tuynel%20theo%20c%C3%B4ng%20ngh%E1%BB%87%20l%C3%B2%20tuynel%20di%20%C4%91%E1%BB%99ng%20m%E1%BB%9Bi%20nh%E1%BA%A5t%20http%3A%2F%2Frobotxepgach.com%2Fmo-ta-quy-trinh-cong-nghe-san-xuat-gach-tuynel-theo-cong-nghe-lo-tuynel-di-dong-moi-nhat.html\" rel=\"nofollow noopener\" style=\"margin: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32); padding: 0px !important; border: none !important; display: inline !important; box-shadow: none !important;\" target=\"_blank\"><ss class=\"theChampSharingSvg theChampWhatsappSvg\" style=\"width: 35px; height: 35px; background: url(&quot;data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%25%22%20height%3D%22100%25%22%20viewBox%3D%22-5%20-5%2040%2040%22%3E%3Cpath%20id%3D%22arc1%22%20stroke%3D%22%23fff%22%20stroke-width%3D%222%22%20fill%3D%22none%22%20d%3D%22M%2011.579798566743314%2024.396926207859085%20A%2010%2010%200%201%200%206.808479557110079%2020.73576436351046%22%3E%3C%2Fpath%3E%3Cpath%20d%3D%22M%207%2019%20l%20-1%206%20l%206%20-1%22%20stroke%3D%22%23fff%22%20stroke-width%3D%222%22%20fill%3D%22none%22%3E%3C%2Fpath%3E%3Cpath%20d%3D%22M%2010%2010%20q%20-1%208%208%2011%20c%205%20-1%200%20-6%20-1%20-3%20q%20-4%20-3%20-5%20-5%20c%204%20-2%20-1%20-5%20-1%20-4%22%20fill%3D%22%23fff%22%3E%3C%2Fpath%3E%3C%2Fsvg%3E&quot;) center center no-repeat; display: block;\"></ss></a></i></li>\r\n	<li class=\"theChampSharingRound\" style=\"margin: 0px !important; padding: 0px !important; border: none !important; font: inherit; vertical-align: baseline; clear: none; float: left !important; list-style: none !important; width: auto; background: 0px 0px !important;\"><i alt=\"More\" class=\"theChampSharing theChampMoreBackground\" style=\"margin: 2px; padding: 0px; border: 0px solid transparent; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; display: block; cursor: pointer; background-color: rgb(238, 142, 45); float: left; color: rgb(255, 255, 255); width: 35px; height: 35px; border-radius: 999px;\" title=\"More\"><ss class=\"theChampSharingSvg theChampMoreSvg\" style=\"width: 35px; height: 35px; background: url(&quot;data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%25%22%20height%3D%22100%25%22%20viewBox%3D%22-4%20-4%2038%2038%22%3E%3Ccircle%20cx%3D%2210%22%20cy%3D%2215%22%20r%3D%223%22%20fill%3D%22%23fff%22%3E%3C%2Fcircle%3E%3Ccircle%20cx%3D%2220%22%20cy%3D%2210%22%20r%3D%223%22%20fill%3D%22%23fff%22%3E%3C%2Fcircle%3E%3Ccircle%20cx%3D%2220%22%20cy%3D%2220%22%20r%3D%223%22%20fill%3D%22%23fff%22%3E%3C%2Fcircle%3E%3Cpath%20d%3D%22M%2010%2015%20L%2020%2010%20m%200%2010%20L%2010%2015%22%20stroke-width%3D%222%22%20stroke%3D%22%23fff%22%3E%3C%2Fpath%3E%3C%2Fsvg%3E&quot;) center center no-repeat; display: block;\"></ss></i></li>\r\n</ul>\r\n\r\n<div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; clear: both;\">&nbsp;</div>\r\n</div>\r\n\r\n<div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; clear: both;\">&nbsp;</div>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">M&Ocirc; H&Igrave;NH QUY TR&Igrave;NH C&Ocirc;NG NGHỆ V&Agrave;</span></p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">PHƯƠNG &Aacute;N KỸ THUẬT C&Ocirc;NG TR&Igrave;NH HẦM L&Ograve; TUYNEL DI ĐỘNG TỰ TH&Acirc;N C&Aacute;CH NHIỆT</span></p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">Giới thiệu sản phẩm&nbsp;</span><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">:</span></p>\r\n\r\n<ol style=\"margin: 0px; padding-right: 0px; padding-left: 0px; border: 0px; font: inherit; vertical-align: baseline; list-style: none; color: rgb(115, 126, 134);\">\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">Đặc điểm của l&ograve; tuynel di động-Movable Tuynel Kilning</span></li>\r\n</ol>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Đặc điểm của l&ograve; tuynel di động do tập đo&agrave;n H.I.S Group thiết kế với kết cấu mới tiết kiệm năng lượng , bảo vệ m&ocirc;i trường, sản lượng cao , hao tốn &iacute;t :</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">&ldquo;l&ograve; tuynel di động với kết cấu mới tiết kiệm năng lượng , bảo vệ m&ocirc;i trường, sản lượng cao , hao tốn &iacute;t &ldquo; , được l&agrave;m với tr&ecirc;n đỉnh l&ograve; kh&ocirc;ng c&oacute; quạt gi&oacute; , lượng gi&oacute; cần trong qu&aacute; tr&igrave;nh để sấy v&agrave; nung mộc ho&agrave;n to&agrave;n nhờ v&agrave;o quạt gi&oacute; khử lưu huỳnh ho&agrave;n th&agrave;nh , kết cấu n&agrave;y c&oacute; thể đảm bảo rằng l&ograve; di chuyển được ổn định , kh&ocirc;ng sản sinh ra bất kỳ 1 rung động n&agrave;o , k&eacute;o d&agrave;i tuổi thọ phần th&acirc;n l&ograve; v&agrave; c&aacute;c nguy&ecirc;n vật liệu chịu nhiệt chịu lửa .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><img alt=\"\" class=\"aligncenter wp-image-1446\" height=\"555\" sizes=\"(max-width: 650px) 100vw, 650px\" src=\"http://robotxepgach.com/wp-content/uploads/2017/11/quy-trinh-c%C3%B4ng-nghe-lo-tuynel-di-%C4%91ong-300x256.png\" srcset=\"http://robotxepgach.com/wp-content/uploads/2017/11/quy-trinh-công-nghe-lo-tuynel-di-đong-300x256.png 300w, http://robotxepgach.com/wp-content/uploads/2017/11/quy-trinh-công-nghe-lo-tuynel-di-đong-768x656.png 768w, http://robotxepgach.com/wp-content/uploads/2017/11/quy-trinh-công-nghe-lo-tuynel-di-đong-1024x874.png 1024w, http://robotxepgach.com/wp-content/uploads/2017/11/quy-trinh-công-nghe-lo-tuynel-di-đong-180x154.png 180w, http://robotxepgach.com/wp-content/uploads/2017/11/quy-trinh-công-nghe-lo-tuynel-di-đong-600x512.png 600w, http://robotxepgach.com/wp-content/uploads/2017/11/quy-trinh-công-nghe-lo-tuynel-di-đong-171x146.png 171w, http://robotxepgach.com/wp-content/uploads/2017/11/quy-trinh-công-nghe-lo-tuynel-di-đong-50x43.png 50w, http://robotxepgach.com/wp-content/uploads/2017/11/quy-trinh-công-nghe-lo-tuynel-di-đong-88x75.png 88w\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; max-width: 100%; height: auto;\" width=\"650\" /></p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Kết cấu mới hợp l&yacute; của l&ograve; đảm bảo trong 10 năm kh&ocirc;ng phải sửa chữa nhiều , c&aacute;c nguy&ecirc;n vật liệu chịu nhiệt chịu lửa đảm bảo 5 năm kh&ocirc;ng phải sửa chữa thay nhiều . Đồng thời c&ograve;n giảm tối thiểu d&acirc;y trượt tiếp x&uacute;c của d&acirc;y c&aacute;p 3 pha , n&acirc;ng cao tuổi thọ v&agrave; t&iacute;nh năng sử dụng an to&agrave;n cho d&acirc;y c&aacute;p 3 pha , gi&uacute;p cho doanh nghiệp giảm tối thiểu vốn đi v&agrave;o hoạt động .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Kh&oacute;i được th&ocirc;ng qua đường ống kh&oacute;i trượt đi v&agrave;o hệ thống sử l&yacute; kh&iacute; thải , nắp trượt của hệ thống v&agrave; l&ograve; di chuyển c&ugrave;ng l&uacute;c , đạt đến mức độ tiếp x&uacute;c v&ocirc; c&ugrave;ng k&iacute;n , kh&ocirc;ng bị hở , l&agrave;m cho lượng gi&oacute; trong l&ograve;ng l&ograve; lu&ocirc;n lu&ocirc;n ổn định . Sự vận h&agrave;nh hợp l&yacute; của hệ thống đưa gi&oacute; đ&agrave;o thải kh&iacute; thải , đ&atilde; l&agrave;m giảm đ&aacute;ng kể lượng đ&agrave;o thải kh&iacute; thải từ c&aacute;c thiết bị sử l&yacute; khử huỳnh , c&agrave;ng dễ d&agrave;ng c&oacute; thể đạt đến ti&ecirc;u chuẩn về bảo vệ m&ocirc;i trường .</p>\r\n\r\n<blockquote style=\"margin: 0px; padding: 0px; border-left: 0px; border-top-style: initial; border-right-style: initial; border-bottom-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: initial; border-image: initial; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: Arial, Arial, Tahoma, sans-serif; vertical-align: baseline; quotes: none; color: rgb(68, 68, 68);\">\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">&gt;&gt;&gt; Xem Th&ecirc;m:</span></p>\r\n</blockquote>\r\n\r\n<ul style=\"margin: 0px; padding-right: 0px; padding-left: 0px; border: 0px; font: inherit; vertical-align: baseline; list-style: none; color: rgb(115, 126, 134);\">\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><a href=\"http://robotxepgach.com/cong-nghe-san-xuat-gach-tuynel-moi-su-dung-100-dat-doi-html.html\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32);\">C&ocirc;ng Nghệ sản xuất gạch tuynel từ Đất Đ</a>ồi</li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><a href=\"http://robotxepgach.com/giai-phap-cat-giam-chi-phi-cho-cac-lo-gach-tuynel.html\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32);\">Giải ph&aacute;p cắt giảm chi ph&iacute; &nbsp;sản xuất v&agrave; chi ph&iacute; vận h&agrave;nh cho nh&agrave; m&aacute;y gạch tuynel</a></li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><a href=\"http://robotxepgach.com/su-dung-cong-nghe-robot-xep-gach-nhung-dieu-can-luu-y-html.html\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32);\">Những sai lầm trong đầu tư nh&agrave; m&aacute;y gạch tuynel hiện nay</a></li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><a href=\"http://robotxepgach.com/tu-van-cap-chuyen-doi-va-xay-moi-du-an-nha-may-san-xuat-gach-tuynel-bang-cong-nghe-moi-nhat-2017-html-html.html\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32);\">Tư vấn n&acirc;ng cấp v&agrave; chuyển đổi l&ograve; hoffman sang l&ograve; tuynel c&ocirc;ng nghệ mới nhất năm 2017</a></li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><a href=\"http://robotxepgach.com/cong-nghe-san-xuat-gach-tuynel-cach-phan-biet-lo-xoay-tuynel-va-lo-vong-hoffman.html\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32);\">C&ocirc;ng nghệ l&ograve; tuynel di động, phương &aacute;n thay thế ho&agrave;n hảo cho l&ograve; v&ograve;ng Hoffman</a></li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><a href=\"http://robotxepgach.com/tam-quan-trong-cua-viec-thi-nghiem-nguyen-lieu-truoc-khi-dau-tu-xay-dung-nha-may-gach-tuynel.html\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32);\">Tầm quan trọng của việc h&oacute;a nghiệm nguy&ecirc;n liệu khi đầu tư nh&agrave; m&aacute;y gạch tuynel mới</a></li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><a href=\"http://robotxepgach.com/lo-tuynel-di-dong-la-gi-movable-tuynel-kilning-dinh-nghia-va-ten-goi-chinh-xac-html.html\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32);\">L&ograve; tuynel di động l&agrave; g&igrave;? Movable Tuynel Kinling</a></li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><a href=\"http://robotxepgach.com/cong-nghe-san-xuat-gach-tuynel-cach-phan-biet-lo-xoay-tuynel-va-lo-vong-hoffman.html\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32);\">C&aacute;ch ph&acirc;n biệt giữa l&ograve; tuynel di động v&agrave; l&ograve;ng v&ograve;ng hoffman, tr&aacute;nh nhầm lẫn</a></li>\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><a href=\"http://robotxepgach.com/tam-quan-trong-cua-viec-thi-nghiem-nguyen-lieu-truoc-khi-dau-tu-xay-dung-nha-may-gach-tuynel.html\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-decoration-line: none; outline: 0px; color: rgb(255, 168, 32);\">H&oacute;a nghiệm nguy&ecirc;n liệu sản xuất gạch tuynel, c&oacute; cần thiết hay kh&ocirc;ng??</a></li>\r\n</ul>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">To&agrave;n bộ hoạt động của l&ograve; đ&atilde; sử dụng hệ điều h&agrave;nh 1 n&uacute;t khởi động , kh&ocirc;ng cần người khống chế , thực hiện th&agrave;nh c&ocirc;ng qu&aacute; tr&igrave;nh tự động h&oacute;a đốt c&ugrave;ng với chức năng di chuyển của l&ograve;.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Tại Trung Quốc đ&atilde; ph&aacute;t minh th&agrave;nh c&ocirc;ng l&ograve; quay với c&ocirc;ng nghệ v&agrave; kỹ thuật nung đốt sử dụng kh&iacute; tự nhi&ecirc;n để nung đốt c&aacute;c nguy&ecirc;n vật liệu gạch , v&agrave; chất lượng sản phẩm được n&acirc;ng cao r&otilde; rệt , ph&aacute;t minh bảo vệ m&ocirc;i trường n&agrave;y đ&atilde; kh&aacute;ch h&agrave;ng sản xuất chế tạo nguy&ecirc;n vật liệu x&acirc;y dựng v&agrave; c&aacute;c ban ngh&agrave;nh bảo vệ m&ocirc;i trường tại Tứ Xuy&ecirc;n, Thiểm T&acirc;y, Sơn Đ&ocirc;ng , H&agrave; Bắc, Tứ Xuy&ecirc;n, Quảng Ch&acirc;u&hellip; c&ocirc;ng nhận v&agrave; khẳng định .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">To&agrave;n bộ hệ thống l&ograve; di chuyển tr&ecirc;n b&aacute;nh xe được hỗ trợ k&eacute;p c&oacute; thể điều chỉnh phương hướng , đảm bảo di chuyển của l&ograve; được ổn định an to&agrave;n, v&agrave; kh&ocirc;ng xảy ra g&atilde;y trục , kh&ocirc;ng xảy ra hiện tượng b&aacute;nh xe chạy khỏi đường ray .&nbsp; Kh&ocirc;ng cần phải t&iacute;nh to&aacute;n khoảng c&aacute;ch đi v&agrave;o của l&ograve; với c&aacute;c khối gạch ( sự thay đổi của c&aacute;c khối gạch ) , c&oacute; thể đ&aacute;p ứng mọi y&ecirc;u cầu về sản xuất c&aacute;c loại gạch v&agrave; phương thức xếp mộc kh&aacute;c nhau , kh&ocirc;ng cần điều chỉnh , thực hiện vận h&agrave;nh tự động h&oacute;a nung đốt nhiều loại sản phẩm v&agrave; nhiều loại gạch kh&aacute;c nhau .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><img alt=\"\" class=\"aligncenter wp-image-1447\" height=\"365\" sizes=\"(max-width: 650px) 100vw, 650px\" src=\"http://robotxepgach.com/wp-content/uploads/2017/11/l%C3%B2-%C4%91%C4%A9a-s%E1%BA%A3n-xu%E1%BA%A5t-g%E1%BA%A1ch-tuynel-300x169.jpg\" srcset=\"http://robotxepgach.com/wp-content/uploads/2017/11/lò-đĩa-sản-xuất-gạch-tuynel-300x169.jpg 300w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-đĩa-sản-xuất-gạch-tuynel-180x101.jpg 180w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-đĩa-sản-xuất-gạch-tuynel-260x146.jpg 260w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-đĩa-sản-xuất-gạch-tuynel-50x28.jpg 50w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-đĩa-sản-xuất-gạch-tuynel-133x75.jpg 133w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-đĩa-sản-xuất-gạch-tuynel.jpg 500w\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; max-width: 100%; height: auto;\" width=\"650\" /></p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Tại xưởng sản xuất b&ecirc;n trong v&agrave; ngo&agrave;i của l&ograve; đều c&oacute; thiết kế tường giữ nhiệt v&agrave; chống bụi , nhằm kh&aacute;c phục điều kiện thời tiết khắc nghiệt như mưa gi&oacute; hay nhiệt độ qu&aacute; thấp l&agrave;m ảnh hưởng đến c&aacute;c khối mộc v&agrave; sự vận h&agrave;nh của l&ograve; , với thiết kế như vậy đ&atilde; l&agrave;m thay đổi điều kiện m&ocirc;i trường l&agrave;m việc v&agrave; lao động .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Dựa v&agrave;o vị tr&iacute; địa l&yacute; , nhiệt độ n&oacute;ng ấm lạnh tại mỗi doanh nghiệp , m&agrave; c&oacute; thiết kế khoa học nhằm k&eacute;o d&agrave;i thời gian vận h&agrave;nh của l&ograve; tại những nơi c&oacute; điều kiện nhiệt độ kh&aacute;c nhau , nhằm đảm bảo t&iacute;nh ổn định của c&ocirc;ng nghệ sản xuất , gi&uacute;p cho sản lượng v&agrave; chất lượng sản phẩm được n&acirc;ng cao r&otilde; rệt .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Tập đo&agrave;n H.I.S Group đ&atilde; ph&aacute;t minh v&agrave; đưa v&agrave;o hoạt động th&agrave;nh c&ocirc;ng hệ thống l&ograve; tuynel di động với kết cấu mới tiết kiệm năng lượng , bảo vệ m&ocirc;i trường, sản lượng cao , hao tốn &iacute;t , với đặc điểm l&agrave; vốn đầu tư &iacute;t , thời gian x&acirc;y dựng ngắn, chất lượng đảm bảo , vốn đi v&agrave;o vận h&agrave;nh nhỏ , hiệu quả sản xuất cao , tỷ lệ phải sửa chữa thấp , sản lượng cao hao tốn &iacute;t , tiết kiệm bảo vệ m&ocirc;i trường , qu&aacute; tr&igrave;nh tự động h&oacute;a cao &hellip;vv.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">L&ograve; tuynel di động&nbsp; với kết cấu mới tiết kiệm năng lượng , bảo vệ m&ocirc;i trường, sản lượng cao , hao tốn &iacute;t , ph&ugrave; hợp với c&aacute;c loại nguy&ecirc;n liệu như sau : than đ&aacute;, v&ocirc;i bột , đ&aacute; phiến , đất s&eacute;t , b&ugrave;n tại s&ocirc;ng hồ , b&ugrave;n tại đ&ocirc; thị , r&aacute;c thải vật liệu x&acirc;y dựng , c&aacute;c chất thải cứng kh&aacute;c nhau, r&aacute;c thải c&ocirc;ng nghiệp độc hại &hellip;vv . C&oacute; thể nung đốt nhiều loại gạch ph&ugrave; hợp với y&ecirc;u cầu thị trường x&acirc;y dựng nguy&ecirc;n vật liệu kh&aacute;c nhau : gạch đặc , gạch nhiều lỗ , gạch lỗ , gạch giữ nhiệt .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><img alt=\"\" class=\"aligncenter wp-image-1427\" height=\"541\" sizes=\"(max-width: 650px) 100vw, 650px\" src=\"http://robotxepgach.com/wp-content/uploads/2017/10/l%C3%B2-%C4%91%C4%A9a-tuynel-300x250.jpg\" srcset=\"http://robotxepgach.com/wp-content/uploads/2017/10/lò-đĩa-tuynel-300x250.jpg 300w, http://robotxepgach.com/wp-content/uploads/2017/10/lò-đĩa-tuynel-768x639.jpg 768w, http://robotxepgach.com/wp-content/uploads/2017/10/lò-đĩa-tuynel-180x150.jpg 180w, http://robotxepgach.com/wp-content/uploads/2017/10/lò-đĩa-tuynel-600x499.jpg 600w, http://robotxepgach.com/wp-content/uploads/2017/10/lò-đĩa-tuynel-175x146.jpg 175w, http://robotxepgach.com/wp-content/uploads/2017/10/lò-đĩa-tuynel-50x42.jpg 50w, http://robotxepgach.com/wp-content/uploads/2017/10/lò-đĩa-tuynel-90x75.jpg 90w, http://robotxepgach.com/wp-content/uploads/2017/10/lò-đĩa-tuynel.jpg 817w\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; max-width: 100%; height: auto;\" width=\"650\" /></p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Tập đo&agrave;n H.I.S Group với ph&aacute;t minh đầu ti&ecirc;n của l&ograve; về kết cấu mới , đi đầu trong ngh&agrave;nh về đảm bảo động lực hao tốn so với c&aacute;c loại l&ograve; kh&aacute;c c&oacute; thể tiết kiệm đến 50% / năm, thực hiện th&agrave;nh c&ocirc;ng tiết kiệm nguy&ecirc;n liệu đốt đạt tới 30% , sản lương n&acirc;ng cao đến 30% , vốn đi v&agrave;o hoạt động nhỏ , ( mỗi vi&ecirc;n gạch c&oacute; thể tiết kiệm 60-90 đồng / năm ) , gi&uacute;p n&acirc;ng cao sức cạnh tranh của c&aacute;c doanh nghiệp sản xuất nguy&ecirc;n vật liệu x&acirc;y dựng tại địa b&agrave;n .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Tập đo&agrave;n H.I.S Group cam kết cung cấp cho người d&ugrave;ng dịch vụ tốt nhất , c&oacute; thể dựa v&agrave;o nguy&ecirc;n liệu , địa l&yacute; v&agrave; t&igrave;nh h&igrave;nh giao th&ocirc;ng kh&aacute;c nhau của mỗi kh&aacute;ch h&agrave;ng , m&agrave; c&oacute; thể thiết kế v&agrave; quy hoạch to&agrave;n c&ocirc;ng xưởng ph&ugrave; hợp với từng địa h&igrave;nh , đảm bảo l&ograve; được x&acirc;y dựng tiết kiệm , bảo vệ m&ocirc;i trường , cho sản lượng cao hao tốn &iacute;t . Gi&uacute;p cho kh&aacute;ch h&agrave;ng c&oacute; thể k&eacute;o d&agrave;i thời gian sử dụng v&agrave; cạnh trạnh mạnh về tiết kiệm , bảo vệ m&ocirc;i trường , đưa doanh nghiệp trở th&agrave;nh doanh nghiệp gạch m&agrave;u xanh , c&ocirc;ng ty đảm bảo cung cấp kịp thời , ho&agrave;n thiện , m&atilde;n nguyện về phục vụ cho to&agrave;n bộ kh&aacute;ch h&agrave;ng .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-align: center;\">Phương &aacute;n thiết kế ph&ugrave; hợp từng địa h&igrave;nh</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-align: center;\"><img alt=\"\" class=\"aligncenter wp-image-1448\" height=\"365\" sizes=\"(max-width: 650px) 100vw, 650px\" src=\"http://robotxepgach.com/wp-content/uploads/2017/11/l%C3%B2-xoay-tuynel-300x169.jpg\" srcset=\"http://robotxepgach.com/wp-content/uploads/2017/11/lò-xoay-tuynel-300x169.jpg 300w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-xoay-tuynel-180x101.jpg 180w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-xoay-tuynel-260x146.jpg 260w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-xoay-tuynel-50x28.jpg 50w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-xoay-tuynel-133x75.jpg 133w, http://robotxepgach.com/wp-content/uploads/2017/11/lò-xoay-tuynel.jpg 500w\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; max-width: 100%; height: auto;\" width=\"650\" /></p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; text-align: center;\">Thiết kế khử lưu huỳnh di động theo h&igrave;nh thức mở tại miền nam ( c&oacute; thể cố định ) .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Những năm gần đ&acirc;y, Tập đo&agrave;n H.I.S Group lu&ocirc;n lu&ocirc;n ki&ecirc;n tr&igrave; với quan niệm v&agrave; mục đ&iacute;ch<span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">&nbsp;&ldquo; Lựa chọn nhưng sản phẩm thiết bị từ&nbsp;</span>H.I.S Group<span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">&nbsp;l&agrave; lựa chọn th&agrave;nh c&ocirc;ng- Choose&nbsp;</span>H.I.S Group<span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">&nbsp;choose Success &rdquo;</span>&nbsp;, những th&agrave;nh t&iacute;ch x&acirc;y dựng l&ograve; về tiết kiệm năng lượng , bảo vệ m&ocirc;i trường , sản lượng cao , &iacute;t hao tốn , được trải d&agrave;i tr&ecirc;n hơn 20 tỉnh th&agrave;nh khu tự trị khắp tr&ecirc;n to&agrave;n quốc , từ khu vực trung nguy&ecirc;n đến khu vực t&acirc;y nam , đ&ocirc;ng nam , t&acirc;y bắc , h&oacute;a đ&ocirc;ng , h&ograve;a bắc Trương Gia Khẩu ( c&ugrave;ng vĩ độ với tỉnh Li&ecirc;u Ninh ) , xuất ra nước người như Việt Nam v&agrave; c&aacute;c nước trong khu vực D&ocirc;ng Nam &Aacute; , Nam &Aacute;, Nga, M&ocirc;ng Cổ, Nam Phi&hellip;v&agrave; đ&atilde; d&agrave;nh được những th&agrave;nh tựu nhất định của c&aacute;c bạn b&egrave; trong v&agrave; ngo&agrave;i nước , v&agrave; nhận được sự khẳng định từ c&aacute;c chuy&ecirc;n gia v&agrave; bạn b&egrave; trong ngh&agrave;nh .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Những c&ocirc;ng tr&igrave;nh x&acirc;y dựng về tiết kiệm năng lượng , bảo vệ m&ocirc;i trường , sản lượng cao , hao tốn &iacute;t của Tập đo&agrave;n H.I.S Group từ chất lượng , đến sản lượng , sự hao tổn , v&agrave; ti&ecirc;u chuẩn bảo vệ m&ocirc;i trường ,&nbsp; c&ugrave;ng với vốn đi v&agrave;o hoạt động đều đứng vị tr&iacute; h&agrave;ng đầu trong ngh&agrave;nh , thu được nhiều th&agrave;nh tựu đ&aacute;ng kể , v&agrave; đ&atilde; khẳng định được sữ nỗ lực kh&ocirc;ng ngừng nghỉ của Tập đo&agrave;n H.I.S Group trong nhiều năm qua , đồng thời cũng l&agrave; động lực để Tập đo&agrave;n H.I.S Group nỗ lực hơn , kh&ocirc;ng ngừng nghỉ , đi đến mức độ cao hơn , tiến tới y&ecirc;u cầu tốt hơn .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Tập đo&agrave;n H.I.S Group, chuy&ecirc;n nghi&ecirc;n cứu ,thiết kế, thi c&ocirc;ng c&ocirc;ng tr&igrave;nh l&ograve; 1 lần , 2 lần sấy đốt , c&ugrave;ng với chuy&ecirc;n sản xuất m&aacute;y phụ trợ tuyến v&agrave; chuy&ecirc;n gia c&ocirc;ng chế tạo c&aacute;c thiết bị nguy&ecirc;n vật liệu d&agrave;nh cho c&aacute;c doanh nghiệp x&acirc;y dựng , c&ocirc;ng ty đ&atilde; c&oacute; chứng chỉ cấp A trong ngh&agrave;nh nguy&ecirc;n vật liệu x&acirc;y dựng , đ&atilde; c&oacute; bằng ph&aacute;t minh s&aacute;ng chế về hệ thống thiết bị khửu lưu huỳnh .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Ngo&agrave;i ra , c&ocirc;ng ty đ&atilde; được nh&agrave; nước cấp 20 bằng ph&aacute;t minh s&aacute;ng chế về kỹ thuật ti&ecirc;n tiến , c&ocirc;ng nghệ ti&ecirc;n tiến,&nbsp; trong lĩnh vực thiết kế chế tạo v&agrave; đi đầu trong ngh&agrave;nh &ldquo; sản xuất l&ograve; quay tiết kiệm năng lượng , bảo vệ m&ocirc;i trường , sản lượng cao , hao tốn &iacute;t &ldquo; .</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Tr&acirc;n trọng k&iacute;nh mời c&aacute;c vị l&atilde;nh đạo , đồng nghiệp v&agrave; bạn b&egrave; đến thăm v&agrave; cho &yacute; kiến về &ldquo; l&ograve; tuynel di động với kết cấu mới tiết kiệm năng lượng , bảo vệ m&ocirc;i trường, sản lượng cao , hao tốn &iacute;t &rdquo; để c&oacute; những cống hiến v&agrave; ph&aacute;t triển cho ngh&agrave;nh c&ocirc;ng nghiệp nguy&ecirc;n vật liệu .</p>\r\n\r\n<ol style=\"margin: 0px; padding-right: 0px; padding-left: 0px; border: 0px; font: inherit; vertical-align: baseline; list-style: none; color: rgb(115, 126, 134);\">\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">M&ocirc; tả quy tr&igrave;nh c&ocirc;ng nghệ của l&ograve; tuynel di động.</span></li>\r\n</ol>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">QUY TR&Igrave;NH SẢN XUẤT GẠCH BẰNG L&Ograve; TUYNEL DI ĐỘNG</span></p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><iframe allowfullscreen=\"\" frameborder=\"0\" gesture=\"media\" height=\"900\" src=\"https://www.youtube.com/embed/f1lQfk_2qqk?start=51&amp;wmode=transparent&amp;rel=0&amp;feature=oembed\" style=\"margin: 0px; padding: 0px; border-width: 0px; border-style: initial; font: inherit; vertical-align: baseline; max-width: 100%; max-height: 100%; width: 919.391px;\" width=\"1200\"></iframe></p>\r\n\r\n<ol style=\"margin: 0px; padding-right: 0px; padding-left: 0px; border: 0px; font: inherit; vertical-align: baseline; list-style: none; color: rgb(115, 126, 134);\">\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">Sơ đồ quy tr&igrave;nh c&ocirc;ng nghệ:</span></li>\r\n</ol>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><img alt=\"\" class=\"aligncenter wp-image-1354\" height=\"488\" sizes=\"(max-width: 650px) 100vw, 650px\" src=\"http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391-300x225.jpg\" srcset=\"http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391-300x225.jpg 300w, http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391-768x576.jpg 768w, http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391-1024x768.jpg 1024w, http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391-180x135.jpg 180w, http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391-600x450.jpg 600w, http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391-195x146.jpg 195w, http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391-50x38.jpg 50w, http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391-100x75.jpg 100w, http://robotxepgach.com/wp-content/uploads/2017/11/IMG_5391.jpg 1440w\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; max-width: 100%; height: auto;\" width=\"650\" /></p>\r\n\r\n<ol style=\"margin: 0px; padding-right: 0px; padding-left: 0px; border: 0px; font: inherit; vertical-align: baseline; list-style: none; color: rgb(115, 126, 134);\">\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">M&ocirc; tả quy tr&igrave;nh c&ocirc;ng nghệ.</span></li>\r\n</ol>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Đất nguy&ecirc;n liệu được mua hoặc khai th&aacute;c tại chỗ được&nbsp;&nbsp;&nbsp; vận &nbsp;chuyển đến b&atilde;i chứa đất thường c&oacute; khả năng dự trữ nguy&ecirc;n liệu 6 th&aacute;ng đến 1 năm hoạt động của nh&agrave; m&aacute;y. Nguy&ecirc;n liệu được để ngo&agrave;i trời v&agrave; n&ecirc;n được tưới nước, đảo trộn để đảm bảo qu&aacute; tr&igrave;nh phong h&oacute;a đất. Đất được phong h&oacute;a vận chuyển dần v&agrave;o kho chứa đất trong nh&agrave; c&oacute; m&aacute;i che. Đất n&agrave;y n&ecirc;n l&agrave; đất tương đối kh&ocirc; để qu&aacute; tr&igrave;nh xử l&yacute; nguy&ecirc;n liệu được nhẹ nh&agrave;ng. Kho chứa đất trong nh&agrave; n&ecirc;n c&oacute; khả năng dự trữ cho hoạt động đủ c&ocirc;ng suất nh&agrave; m&aacute;y trong 15 ng&agrave;y, tương đương với phần nguy&ecirc;n liệu đủ d&ugrave;ng cho 1 ng&agrave;y sản xuất 8h/ ca.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Đất trong nh&agrave; với độ ẩm thấp sau đ&oacute; được cấp v&agrave;o m&aacute;y cấp liệu th&ugrave;ng. Ở đ&acirc;y, đất nguy&ecirc;n liệu được cấp v&agrave;o bằng m&aacute;y x&uacute;c v&agrave; rơi qua lưới lọc sơ với mắt lưới khoảng 200 x 200mm để v&agrave;o m&aacute;y cấp liệu th&ugrave;ng. Trong m&aacute;y cấp liệu th&ugrave;ng, đất được c&agrave;o tơi v&agrave; được băng tải x&iacute;ch chuyển xuống băng tải cao su ph&iacute;a dưới c&oacute; t&iacute;ch hợp căn băng điện tử với d&ograve;ng liệu cấp đều đặn đảm bảo cho tỉ lệ trộn than, đất được đồng đều kh&ocirc;ng bị chỗ nhiều chỗ &iacute;t.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Than được mua v&agrave; vận chuyển về kho than thường l&agrave; than c&aacute;m với cỡ hạt c&ograve;n th&ocirc; sau đ&oacute; đi qua m&aacute;y nghiền b&uacute;a để c&oacute; nhi&ecirc;n liệu than mịn rồi cấp v&agrave;o phễu cấp than đặt cạnh băng tải đất. Than từ phễu được cấp tới băng tải than c&oacute; định lượng bằng băng tải tự động v&agrave; ch&iacute;nh x&aacute;c, r&oacute;t v&agrave;o băng tải đất theo một tỉ lệ nhất định t&iacute;nh to&aacute;n theo tỷ lệ cấp phối ph&ugrave; hợp với từng loại nguy&ecirc;n liệu.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Hỗn hợp than, đất sau đ&oacute; được đưa tới m&aacute;y c&aacute;n th&ocirc; bằng băng tải. Ở đ&acirc;y, đất cục lớn được c&aacute;n mỏng xuống với chiều d&agrave;y c&aacute;n khoảng 5 &ndash; 10mm v&agrave; sau đ&oacute; lại rơi xuống băng tải kh&aacute;c&nbsp; để đưa tới m&aacute;y nh&agrave;o hai trục. Tại m&aacute;y nh&agrave;o hai trục đất, than được trộn đều v&agrave; rơi xuống băng tải than để cấp cho m&aacute;y c&aacute;n mịn. Tại đ&acirc;y, đất được c&aacute;n một lần nữa qua m&aacute;y c&aacute;n mịn với khe hở giữa hai l&ocirc; c&aacute;n mỏng hơn trước chỉ c&ograve;n 2-3mm. Với ti&ecirc;u chuẩn ch&acirc;u &Acirc;u th&igrave; khe hở n&agrave;y chỉ l&agrave; 0,7mm để gi&uacute;p ph&aacute; vỡ kết cấu đất hoặc l&agrave;m mịn c&aacute;c vi&ecirc;n sạn nhỏ vốn l&agrave; nguy&ecirc;n nh&acirc;n g&acirc;y ra c&aacute;c vết nứt bề mặt vi&ecirc;n gạch</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Sau m&aacute;y c&aacute;n mịn, nguy&ecirc;n liệu đất sau đ&oacute; được đưa v&agrave;o m&aacute;y nh&agrave;o c&oacute; lưới lọc. Tại đ&acirc;y, hệ thống phun nước tạo ẩm sẽ phun một lượng nước vừa phải tạo ẩm cho đất để tăng t&iacute;nh dẻo của đất l&ecirc;n v&agrave; đ&ugrave;n qua lưới lọc với mắt lưới 50 x 50mm. Tại lưới lọc n&agrave;y, cỏ r&aacute;c sẽ bị cản lại v&agrave; t&aacute;ch ra khỏi d&ograve;ng đất nguy&ecirc;n liệu rơi xuống băng tải than để đưa ra m&aacute;y nh&agrave;o đ&ugrave;n h&uacute;t&nbsp; ch&acirc;n kh&ocirc;ng li&ecirc;n hợp. Trong m&aacute;y nh&agrave;o, đ&ugrave;n h&uacute;t ch&acirc;n kh&ocirc;ng li&ecirc;n hợp n&agrave;y, nguy&ecirc;n liệu được đảo trộn v&agrave; rơi v&agrave;o buồng ch&acirc;n kh&ocirc;ng c&oacute; kết nối với cơ cấu đ&ugrave;n. Tại buồng h&uacute;t ch&acirc;n kh&ocirc;ng, bơm ch&acirc;n kh&ocirc;ng sẽ h&uacute;t kh&ocirc;ng kh&iacute; trong đ&oacute; ra gi&uacute;p giảm thiểu c&aacute;c bọt kh&iacute; c&oacute; thể c&ograve;n tồn tại trong đất để gi&uacute;p kh&acirc;u đ&ugrave;n sẽ &eacute;p đất được chặt hơn. Trong kh&acirc;u đ&ugrave;n &eacute;p, đất được &eacute;p trong xi lanh bằng một trục v&iacute;t xoắn ruột g&agrave; v&agrave; đ&ugrave;n ra ngo&agrave;i qua đầu đ&ugrave;n được thiết kế định h&igrave;nh theo k&iacute;ch thước vi&ecirc;n gạch.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Khi ra khỏi đầu đ&ugrave;n băng tải sẽ đưa sản phẩm đ&ugrave;n tới hệ thống tổ hợp bằng robot. Robot số 1 sẽ chuyển mộc l&ecirc;n hệ băng tải v&agrave;nh khuy&ecirc;n chạy xung quanh l&ograve;, được điều khiển tự động qua hệ thống cảm biến quang điện. Hệ thống băng tải V&agrave;nh khuy&ecirc;n sẽ chuyển gạch mộc chạy đến khu vực hệ thống tổ hợp robot xếp mộc số 2,3 v&agrave; 4. Hệ thống robot xếp mộc số 2 sẽ chuyển gắp mộc từ băng tải v&agrave;nh khuy&ecirc;n xuống băng tải trung gian- di chuy&ecirc;n ngay ph&iacute;a trước cửa l&ograve;.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Tại đ&acirc;y hệ hai robot tự động 3 v&agrave; 4 sẽ gắp v&agrave; xếp mộc từ băng tải tổ hợp xuống l&ograve;ng l&ograve; theo t&iacute;nh to&aacute;n chi tiết v&agrave; khoa học bởi c&aacute;c khối xếp mộc h&igrave;nh dẻ quạt. C&aacute;c khối xếp được xếp cố định v&agrave; kh&ocirc;ng di chuyển trong suốt qu&aacute; tr&igrave;nh s&acirc;y nung diễn ra sau đ&oacute;. Qu&aacute; tr&igrave;nh sản xuất mộc sẽ được diễn ra li&ecirc;n tục từ 15-20 ng&agrave;y t&ugrave;y theo điều kiện thực tế để c&oacute; thể t&iacute;ch được số gạch mộc ph&ugrave; hợp với sản lượng của l&ograve; từ 1,5 triệu đến 1,7 triệu vi&ecirc;n gạch mộc ti&ecirc;u chuẩn tương đương với 2/3 v&ograve;ng quay của l&ograve;.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Ngay khi qu&aacute; tr&igrave;nh t&iacute;ch mộc v&agrave; sấy l&ograve; kết th&uacute;c phần th&acirc;n hầm l&ograve; tuynel sẽ mở của nhận mộc ở ph&iacute;a trước l&ograve; v&agrave; tự động di chuyển tịnh tiến về ph&iacute;a trước theo từng bước di chuyển để tiếp nhận gạch mộc mới chuyển v&agrave;o sấy. Phần gạch nằm ở v&ugrave;ng sấy trước đ&oacute; sẽ được chuyển sang v&ugrave;ng nung ngay ph&iacute;a sau, v&agrave; to&agrave;n bộ phần gạch nằm ở v&ugrave;ng nung sẽ được chuyển sang v&ugrave;ng l&agrave;m lạnh gạch.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Tại của sau của hầm l&ograve; gạch th&agrave;nh phẩm sẽ được lấy ra ngay trong khi qu&aacute; tr&igrave;nh nung sấy gạch vẫn diễn ra ph&iacute;a trước đ&oacute;. Tại đ&acirc;y qua kiểm tra thực tế gạch th&agrave;nh phẩm ngay sau khi ra khỏi l&ograve; nhiệt độ vi&ecirc;n gạch chỉ rơi v&agrave;o khoảng 20-22 độ c t&ugrave;y theo điều kiện m&ocirc;i trường rất an to&agrave;n cho sức khỏe v&agrave; điều kiện l&agrave;m việc của người lao động được cải thiện đ&aacute;ng kể.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Trong qu&aacute; tr&igrave;nh nung, gạch mộc được n&acirc;ng dần nhiệt độ l&ecirc;n đến nhiệt độ kết khối v&agrave; sau đ&oacute; hạ dần nhiệt độ rồi đi ra ngo&agrave;i để trở th&agrave;nh gạch ch&iacute;n th&agrave;nh phẩm, qu&aacute; tr&igrave;nh n&agrave;y thường d&agrave;i hơn, kỹ thuật phức tạp hơn so với kiểu h&igrave;nh l&ograve; cũ. L&agrave;m cho vi&ecirc;n gạch c&oacute; m&agrave;u sắc đẹp, đồng đều, cường độ cao, khối b&ecirc;n vững tỷ lệ th&agrave;nh phẩm đất 99,8%</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><iframe allowfullscreen=\"\" frameborder=\"0\" gesture=\"media\" height=\"900\" src=\"https://www.youtube.com/embed/ekGVB8bDP6M?wmode=transparent&amp;rel=0&amp;feature=oembed\" style=\"margin: 0px; padding: 0px; border-width: 0px; border-style: initial; font: inherit; vertical-align: baseline; max-width: 100%; max-height: 100%; width: 919.391px;\" width=\"1200\"></iframe></p>\r\n\r\n<ul style=\"margin: 0px; padding-right: 0px; padding-left: 0px; border: 0px; font: inherit; vertical-align: baseline; list-style: none; color: rgb(115, 126, 134);\">\r\n	<li style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">Những ưu thế vượt trội của l&ograve; tuynel di động so với l&ograve; trần bằng</span></li>\r\n</ul>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">L&ograve; tuynel di động đ&atilde; loại bỏ một số lượng lớn c&aacute;c xe goong v&agrave; thiết bị phụ trợ như ray xe ph&agrave;&hellip;do đ&oacute; đ&atilde; giảm đ&aacute;ng kể chi ph&iacute; đầu tư, sản xuất của l&ograve; nung tuynel.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">L&ograve; tuynel di động c&oacute; mức tự động h&oacute;a cao, từ kh&acirc;u xử l&yacute; nguy&ecirc;n liệu đến tạo h&igrave;nh xếp mộc đến ra gạch th&agrave;nh phẩm đều được cơ giới h&ograve;a bằng robot tự động, hệ thống kiểm so&aacute;t nhiệt to&agrave;n th&acirc;n l&ograve; hiện đại qua m&agrave;n h&igrave;nh điều khiển trung t&acirc;m, n&ecirc;n vận h&agrave;nh rất dễ d&agrave;ng, tiết kiệm nhi&ecirc;n liệu v&agrave; nh&acirc;n c&ocirc;ng phục vụ, chỉ cần 1 c&ocirc;ng nh&acirc;n vận h&agrave;nh l&ograve; trong m&ocirc;t ca sản xuất.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">L&ograve; c&oacute; thể cho mức sản lượng l&ecirc;n đến 200-400 triệu vi&ecirc;n tr&ecirc;n năm</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">L&ograve; xoay tuynel đặc biệt th&iacute;ch hợp với nhiều loại nguy&ecirc;n liệu như : đất đồi, đất đ&aacute; phong h&oacute;a, phế thải x&acirc;y dựng, thải từ c&aacute;c mỏ quẳng hay thậm ch&iacute; l&agrave; b&ugrave;n thải tạp chất độc hại từ những nh&agrave; m&aacute;y khu chế suất hay luyện gang th&eacute;p&hellip;..</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">L&ograve; sử dụng kết cầu th&eacute;p vững chắc được đặt tr&ecirc;n hệ thống ray kh&eacute;p k&iacute;n c&oacute; đường k&iacute;nh lớn từ 130-180m</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">L&ograve; chạy li&ecirc;n tục bao quanh c&aacute;c khối xếp gạch mộc dược đặt cố định tr&ecirc;n mặt s&agrave;n của l&ograve; nung, hạn chế tối đa hiện tượng đổ vỡ khối xếp gạch trong qu&aacute; tr&igrave;nh nung, sấy, l&agrave;m gi&aacute;n đoạn v&agrave; giảm sản lượng sản xuất gạch</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Phần l&ograve; nung, sấy thường c&oacute; chiều d&agrave;i bằng 2/3 đường k&iacute;nh v&ograve;ng quay, một đầu nhận gạch mộc một đầu thu gạch th&agrave;nh phẩm</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">L&ograve; tuynel di động được thiết kế khoa học, ti&ecirc;n tiến, đảm bảo t&iacute;nh ưu việt của c&ocirc;ng nghệ, kết cầu khoa học, thi c&ocirc;ng tối t&acirc;n, gi&uacute;p đảm bảo hiệu quả bảo &ocirc;n cho to&agrave;n&nbsp; bộ th&acirc;n l&ograve;.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">L&ograve; được thiết kế rất th&acirc;n thiện với m&ocirc;i trường dễ d&agrave;ng tạo cảnh quan khu&acirc;n vi&ecirc;n đẹp như c&ocirc;ng vi&ecirc;n, m&ocirc;i trương l&agrave;m việc s&aacute;ch đẹp, kh&ocirc;ng &ocirc; nhiễm, kh&oacute;i bụi độc hại l&agrave; một trong những điều kiện quan trọng để c&ocirc;ng nh&acirc;n gắn b&oacute; l&acirc;u d&agrave;i với c&ocirc;ng việc, nhất l&agrave; trong điều kiện thiếu h&uacute;t nh&acirc;n c&ocirc;ng v&agrave; lương cơ bản li&ecirc;n tục tăng</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Thời gian thi c&ocirc;ng l&ograve; gắn hơn c&aacute;c loài l&ograve; Tuynel kh&aacute;c, với chi ph&iacute; vận h&agrave;nh v&agrave; bảo tr&igrave; thấp chỉ v&agrave;o khoảng 1% tổng gi&aacute; trị đầu tư l&ograve; trong v&ograve;ng 10 năm.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Chi ph&iacute; vận h&agrave;nh l&ograve; thấp hơn hẳn so với l&ograve; trần phẳng hiện tại với mức ti&ecirc;u hao nhi&ecirc;n liệu thấp, tỷ lệ ti&ecirc;u hao nhiệt năng thấp hơn 200KCAL/KG.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Dễ d&agrave;ng trong kh&acirc;u đ&oacute;ng g&oacute;i th&agrave;nh phẩm, gi&uacute;p giảm bớt nh&acirc;n c&ocirc;ng, đặc biệt cải thiện đ&aacute;ng kể m&ocirc;i trường l&agrave;m việc cho nh&acirc;n c&ocirc;ng trong kh&acirc;u ra l&ograve;, vốn rất &ocirc; nhiễm v&agrave; n&oacute;ng bức v&agrave; độc hại. Đồng thời tiết kiệm thời gian v&agrave; chi ph&iacute;&nbsp; vận chuyển sản phẩm đến c&ocirc;ng tr&igrave;nh.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Một điều v&ocirc; c&ugrave;ng quan trọng l&agrave; to&agrave;n bộ hệ thống l&ograve; tuynel di động được đầu tư đồng bộ từ kh&acirc;u xử l&yacute; nguy&ecirc;n liệu, ng&acirc;m ủ, đến hệ thống xử l&yacute; kh&oacute;i thải độc hại li&ecirc;n ho&agrave;n, với c&ocirc;ng nghệ th&aacute;p khử lưu huỳnh mới lu&ocirc;n l&agrave; điều kiện sống c&ograve;n cho c&aacute;c nh&agrave; m&aacute;y gạch c&ocirc;ng nghệ tuynel mới</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Với c&ocirc;ng nghệ l&ograve;&nbsp; tuynel di động ti&ecirc;n ti&ecirc;n, thế&nbsp; hệ mới cho tỷ lệ đạt th&agrave;nh phẩm cao ở mức tr&ecirc;n 98%, v&agrave; c&ograve;n ở mức 99,6% đối với thế hệ l&ograve; xoay mới nhất, trong khi đ&oacute; ở c&aacute;c c&ocirc;ng nghệ l&ograve; nung hiện tại th&igrave; hiệu suất đốt chỉ ở mức 90%, hoặc cao nhất l&agrave; l&ecirc;n tới 95%, điều n&agrave;y gi&uacute;p gia tăng đ&aacute;ng kể, sản lượng cũng như gi&aacute; th&agrave;nh vi&ecirc;n gạch, tăng t&iacute;nh cạnh tranh trong điều kiện th&igrave; trường c&oacute; nhiều nh&agrave; m&aacute;y với nhiều loại c&ocirc;ng nghệ kh&aacute;c nhau.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">Nh&agrave; m&aacute;y gạch sử dụng c&ocirc;ng nghệ l&ograve; tuynel di động,&nbsp; được x&acirc;y dựng hệ thống quy phạm về vận h&agrave;nh, đồng thời được tiến h&agrave;nh đ&agrave;o tạo c&ocirc;ng nh&acirc;n vận h&agrave;nh theo quy tr&igrave;nh. C&ocirc;ng t&aacute;c tiến h&agrave;nh duy tu, bảo dưỡng, kiểm tra thiết bị định kỳ,&nbsp; v&agrave; xử l&yacute; sự cố kịp thời nếu c&oacute;.</p>\r\n\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">*&nbsp;<span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\"><em style=\"margin: 0px; padding: 0px; border: 0px; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;\">Tất cả H&igrave;nh ảnh chỉ mang t&iacute;nh chất minh họa, mọi thiết kế v&agrave; cơ cầu danh s&aacute;ch thiết bị sẽ được tinh to&agrave;n theo số đầu v&agrave;o v&agrave; y&ecirc;u cầu của từng nơi, n&ecirc;n c&oacute; thể thay đổi m&agrave; kh&ocirc;ng cần c&oacute; sự b&aacute;o trước của b&ecirc;n chuyển giao c&ocirc;ng nghệ khi chưa c&oacute; sự x&aacute;c nhận bằng văn bản c&oacute; dấu v&agrave; chữ k&yacute; của cả 2 b&ecirc;n.</em></span></p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n', 4, NULL, 'cong-nghe-lo-tuynel-moi-nhat', NULL, 'cong-nghe-lo-tuynel-moi-nhat.jpg', 2, 1, 0, 0, 0, NULL, 0, NULL, NULL, 24, NULL, NULL, NULL, '', '', '', '2019-08-01 21:43:05', '2021-07-30 00:56:13', 1, 'post', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `db_posts` (`id`, `name`, `shortdes`, `content`, `cat_id`, `quote`, `link`, `multiple`, `images`, `order`, `user_id`, `choose1`, `choose2`, `choose3`, `choose4`, `choose5`, `price`, `sale_off`, `view`, `name_eng`, `shortdes_eng`, `content_eng`, `title_seo`, `meta_key`, `meta_des`, `created`, `modified`, `user_id_edit`, `type`, `status`, `auto`, `diadiem`, `mucluong`, `thoigianthituyen`, `hannophoso`, `email`, `phone`, `traloi`) VALUES
(12, '5 tiêu chí lựa chọn gạch đỏ xây dựng phù hợp', '<p>5 ti&ecirc;u ch&iacute; lựa chọn gạch đỏ x&acirc;y dựng ph&ugrave; hợp</p>\r\n', '<h3 id=\"1.+Cấu+tạo,+đặc+điểm\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">1. Cấu tạo, đặc điểm</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Gạch đỏ (gạch đất s&eacute;t nung) l&agrave; một loại gạch truyền thống, gi&aacute; th&agrave;nh rất rẻ so với c&aacute;c loại gạch trong x&acirc;y dựng kh&aacute;c. Từ trước đến nay, gạch đỏ l&agrave; loại vật liệu được rất nhiều người lựa chọn v&agrave; sử dụng rất rộng r&atilde;i.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\"><img alt=\"Gạch đất sét nung\" class=\"loaded\" data-original=\"https://img.cdn9h.com/article/2019_1_w3/492-gach-dat-set-nung.jpeg\" data-was-processed=\"true\" src=\"https://img.cdn9h.com/article/2019_1_w3/492-gach-dat-set-nung.jpeg\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: middle; border-style: none; height: 375px; width: 500px;\" /></em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\">Gạch đất s&eacute;t nung</em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Dưới đ&acirc;y l&agrave; một số đặc điểm của gạch đất s&eacute;t nung:</p>\r\n\r\n<ul style=\"box-sizing: inherit; font-family: font-normal; margin-right: 0px; margin-left: 0px; padding-right: 0px; padding-left: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; vertical-align: baseline; list-style-position: initial; list-style-image: initial; margin-bottom: 2rem !important; margin-top: -0.5rem !important;\">\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline; text-align: justify;\">\r\n	<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 1rem !important;\">C&oacute; độ bền cao trong c&aacute;c c&ocirc;ng tr&igrave;nh x&acirc;y dựng.</p>\r\n	</li>\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline; text-align: justify;\">\r\n	<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 1rem !important;\">Gạch đất s&eacute;t nung l&agrave; loại vật liệu rất dễ vỡ, c&oacute; thể g&acirc;y dạn vỡ &nbsp;trong qu&aacute; tr&igrave;nh vận chuyển.</p>\r\n	</li>\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline; text-align: justify;\">\r\n	<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 1rem !important;\">Khả năng chịu lực của gạch đất s&eacute;t nung thấp.</p>\r\n	</li>\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline; text-align: justify;\">\r\n	<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 1rem !important;\">Trong qu&aacute; tr&igrave;nh sản xuất gạch đỏ, rất nhiều lượng kh&iacute; độc sản sinh ra m&ocirc;i trường l&agrave;m &ocirc; nhiễm m&ocirc;i trường v&agrave; sức khỏe của con người.</p>\r\n	</li>\r\n</ul>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Mỗi vi&ecirc;n gạch đỏ thường c&oacute; trọng lượng khoảng 2kg v&agrave; n&oacute; c&oacute; khả năng h&uacute;t ẩm từ 14%-18%.</p>\r\n\r\n<h3 id=\"2.+Quy+cách\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">2. Quy c&aacute;ch</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">K&iacute;ch thước của gạch đất s&eacute;t nung 2 lỗ l&agrave;: 220 x105 x 60 mm, k&iacute;ch thước gạch đất s&eacute;t nung 4 lỗ l&agrave;: 80x 80x 180mm, ...</p>\r\n\r\n<h3 id=\"3.+Phân+loại\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">3. Ph&acirc;n loại</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Gạch đất s&eacute;t nung được ph&acirc;n th&agrave;nh 3 loại cụ thể như sau:</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\"><em style=\"box-sizing: inherit;\">a.&nbsp;<span style=\"box-sizing: inherit; font-family: font-bold !important; font-weight: bolder;\"><a href=\"https://9houz.com/bai-viet/chuyen-gia-tra-loi-xay-nha-bang-gach-dac-hay-gach-lo\" style=\"box-sizing: inherit; font: inherit; color: inherit; background-color: transparent; margin: 0px; padding: 0px; vertical-align: baseline; text-decoration-line: none;\">Gạch đặc</a></span>&nbsp;đất s&eacute;t nung</em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Đặc điểm: Gạch đặc đất s&eacute;t nung c&oacute; k&iacute;ch thước chủ yếu l&agrave; 220x105x55 mm, gạch khu&ocirc;n đặc, c&oacute; m&agrave;u đỏ hoặc đỏ sẫm. Gạch đặc đất s&eacute;t nung c&oacute; khả năng chịu lực v&agrave; chống thấm tốt, v&igrave; vậy thường được sử dụng trong thi c&ocirc;ng tường, c&aacute;c kết cấu m&oacute;ng tường, x&acirc;y bể nước, nh&agrave; vệ sinh. Gạch đỏ đặc được chia l&agrave;m 3 loại với cường độ l&agrave; A1, A2, v&agrave; B.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\"><img alt=\"Gạch đặc đất sét nung\" class=\"loaded\" data-original=\"https://img.cdn9h.com/article/2019_1_w3/492-gach-dac-dat-set-nung.jpeg\" data-was-processed=\"true\" src=\"https://img.cdn9h.com/article/2019_1_w3/492-gach-dac-dat-set-nung.jpeg\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: middle; border-style: none; height: 428px; width: 602px;\" /></em></p>\r\n\r\n<p><ins class=\"adsbygoogle adBlock\" data-ad-client=\"ca-pub-6039645378922607\" data-ad-layout=\"in-article\" data-ad-slot=\"8812680089\" data-adsbygoogle-status=\"done\" style=\"box-sizing: inherit; font-family: font-normal; margin: 0px; padding: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; vertical-align: baseline; display: block; height: 250px; width: 950px;\"><ins id=\"aswift_2_expand\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; display: inline-table; border: none; height: 250px; position: relative; visibility: visible; width: 950px; background-color: transparent;\"><ins id=\"aswift_2_anchor\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; display: block; border: none; height: 250px; position: relative; visibility: visible; width: 950px; background-color: transparent;\"><iframe allowfullscreen=\"true\" allowtransparency=\"true\" frameborder=\"0\" height=\"250\" hspace=\"0\" id=\"aswift_2\" marginheight=\"0\" marginwidth=\"0\" name=\"aswift_2\" scrolling=\"no\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; left: 0px; position: absolute; top: 0px; border-width: 0px; border-style: initial; width: 950px; height: 250px;\" vspace=\"0\" width=\"950\"></iframe></ins></ins></ins></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\">Gạch đặc đất s&eacute;t nung</em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Ưu điểm: &nbsp;Khả năng chịu lực tốt, chống thấm cao.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Nhược điểm: trọng lượng của gạch đặc đất s&eacute;t nung nặng hơn so với c&aacute;c loại gạch kh&aacute;c n&ecirc;n c&oacute; thể ảnh hưởng đến kết cấu v&agrave; tiến độ thi c&ocirc;ng khi x&acirc;y dựng. Hơn nữa, gi&aacute; th&agrave;nh của gạch đặc c&ograve;n cao hơn so với c&aacute;c loại gạch kh&aacute;c.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\"><em style=\"box-sizing: inherit;\">b.&nbsp;<span style=\"box-sizing: inherit; font-family: font-bold !important; font-weight: bolder;\"><a href=\"https://9houz.com/bai-viet/lua-chon-gach-2-lo-nhu-the-nao-loi-khuyen-tu-kien-truc-su\" style=\"box-sizing: inherit; font: inherit; color: inherit; background-color: transparent; margin: 0px; padding: 0px; vertical-align: baseline; text-decoration-line: none;\">Gạch đỏ 2 lỗ</a></span></em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Đặc điểm: k&iacute;ch thước của gạch đỏ 2 lỗ &nbsp;l&agrave; 220x105x55 mm, gạch c&oacute; m&agrave;u đỏ cam hoặc đỏ sẫm v&agrave; thường được sử dụng cho c&aacute;c c&ocirc;ng tr&igrave;nh nhỏ, kh&ocirc;ng y&ecirc;u cầu khả năng chịu lực cao v&agrave; độ ẩm cao.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\"><img alt=\"Gạch đỏ 2 lỗ\" class=\"loaded\" data-original=\"https://img.cdn9h.com/article/2019_1_w3/l_492-gach-do-2-lo.jpeg\" data-was-processed=\"true\" src=\"https://img.cdn9h.com/article/2019_1_w3/l_492-gach-do-2-lo.jpeg\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: middle; border-style: none; height: 401px; width: 602px;\" /></em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\">Gạch đỏ 2 lỗ</em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Ưu điểm: Gạch đỏ hai lỗ c&oacute; trọng lượng nhẹ hơn gạch đặc n&ecirc;n rất dễ d&agrave;ng để thi c&ocirc;ng, c&oacute; tải trọng kết cấu thấp hơn v&agrave; giảm chi ph&iacute; hơn so với gạch đặc.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Nhược điểm: Kh&ocirc;ng n&ecirc;n sử dụng gạch đỏ hai lỗ đối với tường chịu lực. Do khả năng chống thấm của loại gạch n&agrave;y k&eacute;m n&ecirc;n tr&aacute;nh sử dụng ở c&aacute;c khu vực c&oacute; độ ẩm cao.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\"><em style=\"box-sizing: inherit;\">c.&nbsp;<span style=\"box-sizing: inherit; font-family: font-bold !important; font-weight: bolder;\"><a href=\"https://9houz.com/bai-viet/cach-lua-chon-kich-thuoc-gach-6-lo-phu-hop-voi-tinh-nang-su-dung\" style=\"box-sizing: inherit; font: inherit; color: inherit; background-color: transparent; margin: 0px; padding: 0px; vertical-align: baseline; text-decoration-line: none;\">Gạch đỏ rỗng 6 lỗ</a></span></em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Đặc điểm: k&iacute;ch thước của gạch đỏ rỗng 6 lỗ l&agrave; 220x105x150 mm, thường được sử dụng cho c&aacute;c kết cấu kh&ocirc;ng chịu lực v&agrave; khu vực c&oacute; độ ẩm thấp.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\"><img alt=\"Gạch đỏ rỗng 6 lỗ\" class=\"loaded\" data-original=\"https://img.cdn9h.com/article/2019_1_w3/492-gach-do-rong-6-lo.jpeg\" data-was-processed=\"true\" src=\"https://img.cdn9h.com/article/2019_1_w3/492-gach-do-rong-6-lo.jpeg\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: middle; border-style: none; height: 417px; width: 500px;\" /></em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\">Gạch đỏ rỗng 6 lỗ</em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Loại gạch n&agrave;y c&oacute; thể sử dụng để chống n&oacute;ng cho s&acirc;n m&aacute;i do c&oacute; c&aacute;c lỗ rỗng b&ecirc;n trong sẽ tăng khả năng c&aacute;ch nhiệt hơn c&aacute;c loại gạch kh&aacute;c</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">&nbsp;Ưu điểm: &nbsp;Gạch đỏ rỗng 6 lỗ c&oacute; trọng lượng nhẹ hơn c&aacute;c loại gạch đặc n&ecirc;n rất dễ d&agrave;ng khi thi c&ocirc;ng v&agrave; đẩy nhanh hơn về tiến độ thi c&ocirc;ng, giảm được chi ph&iacute; đầu khi x&acirc;y dựng.</p>\r\n\r\n<p><ins class=\"adsbygoogle adBlock\" data-ad-client=\"ca-pub-6039645378922607\" data-ad-layout=\"in-article\" data-ad-slot=\"8812680089\" data-adsbygoogle-status=\"done\" style=\"box-sizing: inherit; font-family: font-normal; margin: 0px; padding: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; vertical-align: baseline; display: block; height: 250px; width: 950px;\"><ins id=\"aswift_3_expand\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; display: inline-table; border: none; height: 250px; position: relative; visibility: visible; width: 950px; background-color: transparent;\"><ins id=\"aswift_3_anchor\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; display: block; border: none; height: 250px; position: relative; visibility: visible; width: 950px; background-color: transparent;\"><iframe allowfullscreen=\"true\" allowtransparency=\"true\" frameborder=\"0\" height=\"250\" hspace=\"0\" id=\"aswift_3\" marginheight=\"0\" marginwidth=\"0\" name=\"aswift_3\" scrolling=\"no\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; left: 0px; position: absolute; top: 0px; border-width: 0px; border-style: initial; width: 950px; height: 250px;\" vspace=\"0\" width=\"950\"></iframe></ins></ins></ins></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">&nbsp;Nhược điểm: Gạch đỏ rỗng 6 lỗ c&oacute; khả năng chống thấm v&agrave; chịu lực k&eacute;m. Khi &nbsp;sử dụng loại gạch n&agrave;y, n&ecirc;n lưu &yacute; cho phần tường lắp c&aacute;c thiết bị: điều h&ograve;a, tivi... v&igrave; khả năng chịu lực v&agrave; li&ecirc;n kết của gạch k&eacute;m.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\"><span style=\"box-sizing: inherit; font-family: font-bold !important; font-weight: bolder;\">Đọc th&ecirc;m:</span></p>\r\n\r\n<ul style=\"box-sizing: inherit; font-family: font-normal; margin-right: 0px; margin-left: 0px; padding-right: 0px; padding-left: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; vertical-align: baseline; list-style-position: initial; list-style-image: initial; margin-bottom: 2rem !important; margin-top: -0.5rem !important;\">\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline;\"><span style=\"box-sizing: inherit; font-family: font-bold !important; font-weight: bolder;\"><a href=\"https://9houz.com/bai-viet/nhung-dieu-can-biet-ve-gach-ong-trong-xay-dung\" style=\"box-sizing: inherit; font-family: inherit; color: inherit; background-color: transparent; margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline; text-decoration-line: none; font-size: 1rem !important;\">Những điều cần biết về gạch ống trong x&acirc;y dựng</a></span></li>\r\n</ul>\r\n\r\n<h2 id=\"II.+Gạch+tàu+đỏ\" style=\"box-sizing: inherit; line-height: 1.5; border-top: 1px solid rgb(215, 210, 210); text-align: justify; font-family: font-bold !important; margin-top: 1rem !important; margin-bottom: 1rem !important; font-size: 27px !important; padding-top: 1rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">II. Gạch t&agrave;u đỏ</span></h2>\r\n\r\n<h3 id=\"1.+Cấu+tạo\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">1. Cấu tạo</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\"><img alt=\"Tổng hợp các loại gạch tàu\" class=\"loaded\" data-original=\"https://img.cdn9h.com/article/2019_1_w3/l_492-tong-hop-cac-loai-gach-tau.jpeg\" data-was-processed=\"true\" src=\"https://img.cdn9h.com/article/2019_1_w3/l_492-tong-hop-cac-loai-gach-tau.jpeg\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: middle; border-style: none; height: 576px; width: 602px;\" /></em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\">Tổng hợp c&aacute;c loại gạch t&agrave;u</em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Gạch t&agrave;u l&agrave; loại gạch đất s&eacute;t nung, c&oacute; m&agrave;u đỏ n&acirc;u. Gạch t&agrave;u cũng l&agrave; loại gạch được sản xuất từ đất nung ở nhiệt độ cao giống c&aacute;c loại gạch đất nung truyền thống.</p>\r\n\r\n<h3 id=\"2.+Đặc+điểm\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">2. Đặc điểm</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Gạch t&agrave;u c&oacute; khả năng h&uacute;t ẩm rất tốt, v&agrave; mang lại độ thẩm mỹ cao cho c&aacute;c c&ocirc;ng tr&igrave;nh. Tuy nhi&ecirc;n, loại gạch n&agrave;y rất dễ bị b&aacute;m r&ecirc;u, ố v&agrave;ng v&agrave; bạc m&agrave;u trong qu&aacute; tr&igrave;nh sử dụng. Ngo&agrave;i ra, khả năng chịu lực của gạch thấp, v&agrave; rất dễ bị vỡ. Gạch t&agrave;u c&oacute; gi&aacute; th&agrave;nh rẻ hơn c&aacute;c loại gạch kh&aacute;c v&agrave; thường được sử dụng để l&aacute;t s&agrave;n.</p>\r\n\r\n<h3 id=\"3.+Các+loại+gạch+tàu+-+quy+cách+-+trọng+lượng+\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">3. C&aacute;c loại gạch t&agrave;u - quy c&aacute;ch - trọng lượng</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Dưới đ&acirc;y l&agrave; một số loại gạch t&agrave;u:</p>\r\n\r\n<ul style=\"box-sizing: inherit; font-family: font-normal; margin-right: 0px; margin-left: 0px; padding-right: 0px; padding-left: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; vertical-align: baseline; list-style-position: initial; list-style-image: initial; margin-bottom: 2rem !important; margin-top: -0.5rem !important;\">\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline; text-align: justify;\">\r\n	<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 1rem !important;\">Gạch t&agrave;u BT c&oacute; quy c&aacute;ch l&agrave; 300 x 340 x 18 mm v&agrave; trọng lượng 3,8 kg.</p>\r\n	</li>\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline; text-align: justify;\">\r\n	<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 1rem !important;\">Gạch t&agrave;u l&aacute; dừa c&oacute; quy c&aacute;ch l&agrave; 300 x 300 x 20 mm v&agrave; trọng lượng 3,5kg.</p>\r\n	</li>\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline; text-align: justify;\">\r\n	<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 1rem !important;\">Gạch t&agrave;u trơn c&oacute; quy c&aacute;ch l&agrave; 300 x 300 x 20 mm v&agrave; trọng lượng 3.35 kg.</p>\r\n	</li>\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline; text-align: justify;\">\r\n	<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 1rem !important;\">Gạch t&agrave;u lục gi&aacute;c c&oacute; quy c&aacute;ch l&agrave; 200 x 200 x 20 mm v&agrave; trọng lượng 1,35kg.</p>\r\n	</li>\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline; text-align: justify;\">\r\n	<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 1rem !important;\">Gạch t&agrave;u n&uacute;t c&oacute; quy c&aacute;ch l&agrave; 300 x 300 x 20 mm v&agrave; trọng lượng 1,35kg.</p>\r\n	</li>\r\n</ul>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\"><img alt=\"Gạch tàu BT\" class=\"loaded\" data-original=\"https://img.cdn9h.com/article/2019_1_w3/492-gach-tau-bt.jpeg\" data-was-processed=\"true\" src=\"https://img.cdn9h.com/article/2019_1_w3/492-gach-tau-bt.jpeg\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: middle; border-style: none; height: 397px; width: 549px;\" /></em></p>\r\n\r\n<p><ins class=\"adsbygoogle adBlock\" data-ad-client=\"ca-pub-6039645378922607\" data-ad-layout=\"in-article\" data-ad-slot=\"8812680089\" data-adsbygoogle-status=\"done\" style=\"box-sizing: inherit; font-family: font-normal; margin: 0px; padding: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; vertical-align: baseline; display: block; height: 250px; width: 950px;\"><ins id=\"aswift_4_expand\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; display: inline-table; border: none; height: 250px; position: relative; visibility: visible; width: 950px; background-color: transparent;\"><ins id=\"aswift_4_anchor\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; display: block; border: none; height: 250px; position: relative; visibility: visible; width: 950px; background-color: transparent;\"><iframe allowfullscreen=\"true\" allowtransparency=\"true\" frameborder=\"0\" height=\"250\" hspace=\"0\" id=\"aswift_4\" marginheight=\"0\" marginwidth=\"0\" name=\"aswift_4\" scrolling=\"no\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; left: 0px; position: absolute; top: 0px; border-width: 0px; border-style: initial; width: 950px; height: 250px;\" vspace=\"0\" width=\"950\"></iframe></ins></ins></ins></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\">Gạch t&agrave;u BT</em></p>\r\n\r\n<h3 id=\"4.+Ứng+dụng+\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">4. Ứng dụng</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Gạch t&agrave;u thường được d&ugrave;ng để l&aacute;t s&agrave;n nh&agrave;, s&acirc;n vườn, s&acirc;n đ&igrave;nh ch&ugrave;a, đường đi v&agrave; thềm cầu thang,...</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\"><span style=\"box-sizing: inherit; font-family: font-bold !important; font-weight: bolder;\">Đọc th&ecirc;m:</span></p>\r\n\r\n<ul style=\"box-sizing: inherit; font-family: font-normal; margin-right: 0px; margin-left: 0px; padding-right: 0px; padding-left: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; vertical-align: baseline; list-style-position: initial; list-style-image: initial; margin-bottom: 2rem !important; margin-top: -0.5rem !important;\">\r\n	<li style=\"box-sizing: inherit; font-family: inherit; margin: 0px 0px 10px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: 1rem !important; line-height: inherit; color: inherit; vertical-align: baseline;\"><span style=\"box-sizing: inherit; font-family: font-bold !important; font-weight: bolder;\"><a href=\"https://9houz.com/bai-viet/lua-chon-gach-2-lo-nhu-the-nao-loi-khuyen-tu-kien-truc-su\" style=\"box-sizing: inherit; font-family: inherit; color: inherit; background-color: transparent; margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline; text-decoration-line: none; font-size: 1rem !important;\">Lựa chọn gạch 2 lỗ như thế n&agrave;o? Lời khuy&ecirc;n từ kiến tr&uacute;c sư</a></span></li>\r\n</ul>\r\n\r\n<h2 id=\"III.+5+tiêu+chí+khi+lựa+chọn+gạch+đất+sét+nung\" style=\"box-sizing: inherit; line-height: 1.5; border-top: 1px solid rgb(215, 210, 210); text-align: justify; font-family: font-bold !important; margin-top: 1rem !important; margin-bottom: 1rem !important; font-size: 27px !important; padding-top: 1rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">III. 5 ti&ecirc;u ch&iacute; khi lựa chọn gạch đất s&eacute;t nung</span></h2>\r\n\r\n<h3 id=\"1.+Màu+sắc\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">1. M&agrave;u sắc</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">M&agrave;u sắc của gạch cũng l&agrave; một yếu tố quan trọng để thể hiện được chất lượng của vi&ecirc;n gạch. Trong qu&aacute; tr&igrave;nh nung, do qu&aacute; tr&igrave;nh oxi ho&aacute; sắt diễn ra n&ecirc;n gạch đất s&eacute;t nung c&oacute; m&agrave;u đỏ hoặc đỏ sẫm. Tuy nhi&ecirc;n, khi x&acirc;y dựng, bạn kh&ocirc;ng n&ecirc;n lựa chọn những vi&ecirc;n gạch c&oacute; m&agrave;u sắc qu&aacute; nhạt hoặc qu&aacute; đậm v&igrave; n&oacute; sẽ ảnh hưởng đến chất lượng c&ocirc;ng tr&igrave;nh của bạn.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\"><img alt=\"Màu của gạch đỏ nung chuẩn độ\" class=\"loaded\" data-original=\"https://img.cdn9h.com/article/2019_1_w3/l_492-mau-cua-gach-do-nung-chuan-do.jpeg\" data-was-processed=\"true\" src=\"https://img.cdn9h.com/article/2019_1_w3/l_492-mau-cua-gach-do-nung-chuan-do.jpeg\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: middle; border-style: none; height: 641px; width: 602px;\" /></em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\">M&agrave;u của gạch đỏ nung chuẩn độ</em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Gạch c&oacute; m&agrave;u đỏ nhạt l&agrave; loại gạch c&ograve;n non, khi nung chưa đạt đến được độ ti&ecirc;u chuẩn, gạch non n&agrave;y sẽ c&oacute; khả năng chịu lực v&agrave; chống thấm tốt nhưng sẽ kh&ocirc;ng bền theo thời gian. C&ograve;n đối với những loại gạch c&oacute; m&agrave;u đỏ đậm c&oacute; vết ch&aacute;y đen l&agrave; gạch được nung qu&aacute; lửa, n&oacute; sẽ kh&ocirc;ng đ&aacute;p ứng được y&ecirc;u cầu.</p>\r\n\r\n<h3 id=\"2.+Âm+thanh\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">2. &Acirc;m thanh</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">C&oacute; một c&aacute;ch cực kỳ hiệu quả để kiểm tra chất lượng của gạch, đ&oacute; ch&iacute;nh l&agrave; cho ch&uacute;ng v&agrave; chạm với nhau hoặc va chạm với nền xi măng. Nếu sau khi va chạm, tiếng vang to v&agrave; r&otilde; th&igrave; chứng tỏ đ&oacute; l&agrave; loại gạch tốt, ngược lại, nếu &acirc;m thanh ph&aacute;t ra trầm th&igrave; đ&oacute; l&agrave; loại gạch kh&ocirc;ng đạt chất lượng.</p>\r\n\r\n<h3 id=\"3.+Mảnh+vỡ\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">3. Mảnh vỡ</span></h3>\r\n\r\n<p><ins class=\"adsbygoogle adBlock\" data-ad-client=\"ca-pub-6039645378922607\" data-ad-layout=\"in-article\" data-ad-slot=\"8812680089\" data-adsbygoogle-status=\"done\" style=\"box-sizing: inherit; font-family: font-normal; margin: 0px; padding: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; vertical-align: baseline; display: block; height: 250px; width: 950px;\"><ins id=\"aswift_5_expand\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; display: inline-table; border: none; height: 250px; position: relative; visibility: visible; width: 950px; background-color: transparent;\"><ins id=\"aswift_5_anchor\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; display: block; border: none; height: 250px; position: relative; visibility: visible; width: 950px; background-color: transparent;\"><iframe allowfullscreen=\"true\" allowtransparency=\"true\" frameborder=\"0\" height=\"250\" hspace=\"0\" id=\"aswift_5\" marginheight=\"0\" marginwidth=\"0\" name=\"aswift_5\" scrolling=\"no\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: baseline; left: 0px; position: absolute; top: 0px; border-width: 0px; border-style: initial; width: 950px; height: 250px;\" vspace=\"0\" width=\"950\"></iframe></ins></ins></ins></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Để kiểm tra chất lượng của một vi&ecirc;n gạch, ch&uacute;ng ta c&oacute; thể thử bằng c&aacute;ch đập vỡ n&oacute; ra.. Khi đập vỡ gạch, bạn c&oacute; thể kiểm tra được chất lượng v&agrave; &acirc;m thanh của vi&ecirc;n gạch. Nếu như những vụn bột đất s&eacute;t nhỏ ở vi&ecirc;n gạch vỡ ra c&oacute; thể b&oacute;p th&agrave;nh bột th&igrave; bạn kh&ocirc;ng n&ecirc;n lựa chọn v&igrave; n&oacute; l&agrave; gạch k&eacute;m chất lượng.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\"><img alt=\"Kiểm tra chất lượng bên trong gạch bằng mảnh vỡ\" class=\"loaded\" data-original=\"https://img.cdn9h.com/article/2019_1_w3/l_492-kiem-tra-chat-luong-ben-trong-gach-bang-manh-vo.jpeg\" data-was-processed=\"true\" src=\"https://img.cdn9h.com/article/2019_1_w3/l_492-kiem-tra-chat-luong-ben-trong-gach-bang-manh-vo.jpeg\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: middle; border-style: none; height: 339px; width: 602px;\" /></em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\">Kiểm tra chất lượng b&ecirc;n trong gạch bằng mảnh vỡ</em></p>\r\n\r\n<h3 id=\"4.+Quan+sát+mảnh+vỡ+của+gạch\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">4. Quan s&aacute;t mảnh vỡ của gạch</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Nếu bạn thấy một vi&ecirc;n gạch c&oacute; c&aacute;c mảnh vỡ sắc nhọn th&igrave; đ&oacute; ch&iacute;nh l&agrave; một vi&ecirc;n gạch chắc chắn v&agrave; &nbsp;chuẩn chất lượng.</p>\r\n\r\n<h3 id=\"5.+Gạch+tốt+cần+phải+đều+và+phẳng\" style=\"box-sizing: inherit; margin-top: 0px; line-height: 1.5; text-align: justify; font-family: font-bold !important; margin-bottom: 1rem !important; font-size: 25px !important; padding-top: 0.5rem !important;\"><span style=\"box-sizing: inherit; font-weight: bolder;\">5. Gạch tốt cần phải đều v&agrave; phẳng</span></h3>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: justify;\">Một vi&ecirc;n gạch tốt sẽ c&oacute; độ đồng đều &nbsp;v&agrave; độ phẳng nhất định. V&igrave; khi đồng đều v&agrave; phẳng sẽ tạo điều kiện thuận lợi hơn cho c&ocirc;ng tr&igrave;nh của bạn, khiến c&ocirc;ng tr&igrave;nh của bạn chắc chắn v&agrave; đảm bảo được tiến độ thi c&ocirc;ng. Bạn c&oacute; thể kiểm tra độ phẳng của gạch bằng c&aacute;ch &aacute;p hai vi&ecirc;n gạch v&agrave;o nhau.</p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\"><img alt=\"Độ phẳng của gạch\" class=\"loaded\" data-original=\"https://img.cdn9h.com/article/2019_1_w3/492-do-phang-cua-gach.jpeg\" data-was-processed=\"true\" src=\"https://img.cdn9h.com/article/2019_1_w3/492-do-phang-cua-gach.jpeg\" style=\"box-sizing: inherit; font: inherit; margin: 0px; padding: 0px; color: inherit; vertical-align: middle; border-style: none; height: 356px; width: 577px;\" /></em></p>\r\n\r\n<p style=\"box-sizing: inherit; font-family: font-normal, sans-serif; margin-top: 0px; margin-bottom: 1rem; font-size: 14px; text-align: center;\"><em style=\"box-sizing: inherit;\">Độ phẳng của gạch</em></p>\r\n', 7, NULL, '5-tieu-chi-lua-chon-gach-do-xay-dung-phu-hop', NULL, '5-tieu-chi-lua-chon-gach-do-xay-dung-phu-hop.jpeg', 1, 1, 0, 0, 0, NULL, 0, NULL, NULL, 26, NULL, NULL, NULL, '5 tiêu chí lựa chọn gạch đỏ xây dựng phù hợp', '5 tiêu chí lựa chọn gạch đỏ xây dựng phù hợp', '5 tiêu chí lựa chọn gạch đỏ xây dựng phù hợp', '2019-08-01 22:14:49', '2020-09-22 11:12:01', 1, 'post', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'về chúng tôi', '<p>C&ocirc;ng ty TNHH C&ocirc;ng nghệ vật liệu x&acirc;y dựng T&acirc;y Ruitai (sau đ&acirc;y gọi l&agrave; C&ocirc;ng nghệ Ruitai) được th&agrave;nh lập năm 2011 v&agrave; c&oacute; trụ sở tại Khu ph&aacute;t triển c&ocirc;ng nghiệp c&ocirc;ng nghệ cao T&acirc;y An. Đ&acirc;y l&agrave; một chuy&ecirc;n gia tư vấn v&agrave; thiết kế d&acirc;y chuyền sản xuất vật liệu tường thi&ecirc;u kết; C&aacute;c doanh nghiệp c&ocirc;ng nghệ cao trong việc thiết kế v&agrave; x&acirc;y dựng c&aacute;c l&ograve; đốt kh&iacute; đốt tự nhi&ecirc;n, l&ograve; đốt than nghiền th&agrave;nh bột v&agrave; l&ograve; nung c&oacute; tiết diện lớn. C&ocirc;ng ty nghi&ecirc;n cứu v&agrave; ph&aacute;t triển sản xuất tro bay khối lượng cực lớn của gạch thi&ecirc;u kết, l&ograve; nung lắp r&aacute;p mới v&agrave; c&aacute;c bằng s&aacute;ng chế quốc gia kh&aacute;c.</p>\r\n\r\n<p>&nbsp;</p>\r\n', '<h2 style=\"font-style:italic;\"><big>C&ocirc;ng ty TNHH C&ocirc;ng nghệ vật liệu x&acirc;y dựng T&acirc;y Ruitai (sau đ&acirc;y gọi l&agrave; C&ocirc;ng nghệ Ruitai) được th&agrave;nh lập năm 2011 v&agrave; c&oacute; trụ sở tại Khu ph&aacute;t triển c&ocirc;ng nghiệp c&ocirc;ng nghệ cao T&acirc;y An. Đ&acirc;y l&agrave; một chuy&ecirc;n gia tư vấn v&agrave; thiết kế d&acirc;y chuyền sản xuất vật liệu tường thi&ecirc;u kết; C&aacute;c doanh nghiệp c&ocirc;ng nghệ cao trong việc thiết kế v&agrave; x&acirc;y dựng c&aacute;c l&ograve; đốt kh&iacute; đốt tự nhi&ecirc;n, l&ograve; đốt than nghiền th&agrave;nh bột v&agrave; l&ograve; nung c&oacute; tiết diện lớn. C&ocirc;ng ty nghi&ecirc;n cứu v&agrave; ph&aacute;t triển sản xuất tro bay khối lượng cực lớn của gạch thi&ecirc;u kết, l&ograve; nung lắp r&aacute;p mới v&agrave; c&aacute;c bằng s&aacute;ng chế quốc gia kh&aacute;c.</big></h2>\r\n\r\n<h2 style=\"font-style:italic;\"><big>C&ocirc;ng ty hiện đang tham gia v&agrave;o kỹ sư kh&ocirc; người &Yacute;, Roberto Rebuzzi (trước đ&acirc;y l&agrave; Piccinini, gi&aacute;m đốc kỹ thuật Morando), kỹ sư l&ograve; Renzo Tunesi (trước đ&acirc;y l&agrave; gi&aacute;m đốc kỹ thuật của LAVAZZETTI SPA), kỹ sư điện Gianni Spagnolo (trước đ&acirc;y l&agrave; tổng gi&aacute;m đốc Cosmec), kỹ sư nhiệt (Cựu kỹ sư cấp cao của Viện nghi&ecirc;n cứu v&agrave; thiết kế vật liệu tường T&acirc;y An). Tạo ra một đội ngũ kỹ thuật mạnh mẽ kết hợp c&ocirc;ng nghệ ch&acirc;u &Acirc;u v&agrave; c&ocirc;ng nghệ, thiết kế v&agrave; quản l&yacute; địa phương. C&aacute;c giải ph&aacute;p tổng thể cho c&aacute;c nh&agrave; m&aacute;y gạch thi&ecirc;u kết.</big></h2>\r\n\r\n<h2 style=\"font-style:italic;\"><big>Dựa tr&ecirc;n thị trường trong nước, c&ocirc;ng ty t&iacute;ch cực t&igrave;m hiểu thị trường nước ngo&agrave;i v&agrave; đ&atilde; th&agrave;nh lập c&aacute;c chi nh&aacute;nh tại Bangladesh, Ấn Độ v&agrave; Việt Nam, với hoạt động tại hơn 20 quốc gia v&agrave; khu vực.</big></h2>\r\n\r\n<h2 style=\"font-style:italic;\"><big>C&ocirc;ng ty theo đuổi triết l&yacute; kinh doanh &quot;định hướng phấn đấu, lấy kh&aacute;ch h&agrave;ng l&agrave;m trung t&acirc;m&quot; v&agrave; dựa tr&ecirc;n nguy&ecirc;n l&yacute; &quot;đạt được kh&aacute;ch h&agrave;ng, l&agrave;m việc nh&oacute;m, trung thực v&agrave; đ&aacute;ng tin cậy, l&agrave;m việc chăm chỉ, vượt qua ch&iacute;nh m&igrave;nh&quot;, họ đ&atilde; x&acirc;y dựng một hệ thống dịch vụ ho&agrave;n hảo v&agrave; mang lại cho kh&aacute;ch h&agrave;ng kịp thời. Hiệu quả, chuy&ecirc;n nghiệp v&agrave; nhanh ch&oacute;ng đầy đủ dịch vụ.</big></h2>\r\n\r\n<h2 style=\"font-style:italic;\"><big>V&agrave;o th&aacute;ng 4 năm 2018, C&ocirc;ng ty Ruitai Technology v&agrave; Shandong Mining Machine Maike Building Vật liệu M&aacute;y m&oacute;c C&ocirc;ng ty TNHH thống nhất hoạt động, v&agrave; trở th&agrave;nh một doanh nghiệp hiện đại t&iacute;ch hợp thiết kế, sản xuất, b&aacute;n h&agrave;ng v&agrave; dịch vụ. Cung cấp một giải ph&aacute;p tổng thể cho c&aacute;c nh&agrave; m&aacute;y gạch thi&ecirc;u kết!</big></h2>\r\n', 2, NULL, 've-chung-toi', NULL, 've-chung-toi.jpeg', 0, 1, 0, 0, 0, NULL, 0, NULL, NULL, 58, NULL, NULL, NULL, '', '', '', '2019-11-04 11:25:14', '2021-07-30 00:56:18', 1, 'post', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'Vì sao gạch tuynel phải có 3 chấm?', 'Khái niệm gạch 3 chấm là thước đo chất lượng khi lựa chọn gạch tuynel cho công trình, bằng trực quan thông thường khi khách hàng tìm mua sản phẩm gạch tuynel loại A1 yêu cầu đầu tiên là sản phẩm gạch phải có 3 chấm.\r\n ', 'Nguyên nhân gạch tuynel có 3 chấm\r\nGạch mộc sau khi được đùng ra và xếp lên goong bằng hệ thống rô bốt hoặc xếp tay đều tuân theo nguyên tắc 1 viên ngang tiếp xúc với 3 viên dọc, nhằm tối ưu hiệu quả sản xuất trong quá trình nung sấy gạch sẽ được xếp theo hình khối 6 x 18 hoặc 3 x 9\r\n \r\n\r\nGạch mộc được rô bốt xếp lên goong\r\n\r\nTrong quá trình nung sấy ở nhiệt độ 900-1000 độ c, tại các điểm gạch tiếp xúc với nhau thiếu co2, nên tại các điểm tiếp xúc này hình thành các điểm có màu đen mờ mờ nên mọi người thường gọi là gạch tuynel 3 chấm\r\n \r\n\r\nSản phẩm gạch tuynel 3 chấm\r\n \r\nKinh nghiệm khi lựa chon gạch tuynel 3 chấm\r\nGạch tuynel hay gọi gạch đất sét nung 3 chấm thường được phân loại A1, A2... tùy theo chất lượng ra lò sau khi phân loại. Chất lượng gạch gạch ra lò thường được phân loại như sau, bằng mắt thương và kinh nghiệm chúng ta có thể kiểm tra sản phẩm ra lo bằng các đặc điểm sau: Hình dạng, màu sắc, cường độ, kích thước\r\n \r\n  1. Hình dạng, kích thước: Viên gạch vuông vắn, không cong vênh, không sứt cạnh, phồng dộp hay còn gọi là nổ vôi\r\n  2. Màu sắc sản phẩm: Gạch ra lò có màu sẩm, hồng tươi, có bột phấn bao phủ bên ngoài là sản phẩm có chất lượng cao nhất.\r\n  3. Cường độ đạt chuẩn: Cẩm hai viên gạch gỏ nhẹ vào nhau phát ra tiếng kêu cong cong, đanh giòn là sản phẩm có cường độ cao\r\n \r\n\r\nSản phẩm được làm nguội khi ra lò\r\n\r\nTrên đây là một số kiến thức, đặc điểm giúp bạn khi lựa chọn và tìm mua gạch tuynel chất lượng, bảo đảm tính bền vững, cũng như tuổi thọ cho công trình\r\nGạch Tuynel 3 chấm chất lượng cao tại Gạch Việt\r\nGạch Việt khẳng định được vị thế của mình trong thị trường gạch xây dựng với hệ thống nhà máy được trang bị hiện đại tự động hóa hoàn toàn đạt chuẩn, các sản phẩm của chúng tôi luôn đạt chất lượng cao nhất, giá cả hợp lí nhất và hệ thống đại lý phủ rộng Gạch Việt luôn đáp ứng được các nhu cầu của khách hàng, làm hài lòng ngay cả những khách hàng khó tính nhất.', 4, NULL, 'vi-sao-gach-tuynel-phai-co-3-cham', NULL, 'vi-sao-gach-tuynel-phai-co-3-cham.jpg', 0, 1, 0, 0, 0, NULL, 0, NULL, NULL, 34, NULL, NULL, NULL, '', '', '', '2019-11-04 12:52:59', '2021-07-30 00:56:14', NULL, 'post', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `db_posts` (`id`, `name`, `shortdes`, `content`, `cat_id`, `quote`, `link`, `multiple`, `images`, `order`, `user_id`, `choose1`, `choose2`, `choose3`, `choose4`, `choose5`, `price`, `sale_off`, `view`, `name_eng`, `shortdes_eng`, `content_eng`, `title_seo`, `meta_key`, `meta_des`, `created`, `modified`, `user_id_edit`, `type`, `status`, `auto`, `diadiem`, `mucluong`, `thoigianthituyen`, `hannophoso`, `email`, `phone`, `traloi`) VALUES
(16, 'Nguyên lý vận hành lò Tuynel', '<p>Nguy&ecirc;n l&yacute; vận h&agrave;nh l&ograve; Tuynel</p>\r\n', '<p>Hiện nay, c&aacute;c l&ograve; sản xuất gạch Tunel ng&agrave;y c&agrave;ng ph&aacute;t triển nhiều với số lượng rất lớn. Điều n&agrave;y l&agrave; do nhu cầu sử dụng gạch x&acirc;y dựng Tuynel đang rất cao tr&ecirc;n thị trường hiện nay. C&oacute; rất nhiều L&ograve; gạch tuynel ở nước ta hiện nay. So với c&aacute;c l&ograve; nung gạch truyền thống trước đ&acirc;y, c&aacute;c l&ograve; gạch nung Tuynel mới được &aacute;p dụng c&ocirc;ng nghệ của c&aacute;c nước ti&ecirc;n tiến nhằm gi&uacute;p cho việc tiết kiệm thời gian, năng lượng ti&ecirc;u thụ v&agrave; &iacute;t ảnh hưởng đến m&ocirc;i trường. Tuy nhi&ecirc;n, kh&ocirc;ng phải c&oacute; nhiều người hiểu được nguy&ecirc;n l&yacute; vận h&agrave;nh của c&aacute;c l&ograve; gạch Tuynel n&agrave;y. B&agrave;i viết n&agrave;y sẽ gi&uacute;p bạn hiểu r&otilde; hơn về quy tr&igrave;nh sản xuất gạch Tuynel một c&aacute;ch kh&aacute;i qu&aacute;t nhất. H&igrave;nh 1. L&ograve; nung gạch Tuynel đang rất ph&aacute;t triển Quy tr&igrave;nh vận h&agrave;nh l&ograve; nung gạch Tuynel - C&aacute;c l&ograve; nung hiện đại sẽ c&oacute; một lớp c&aacute;ch nhiệt, đặc biệt l&ograve; c&oacute; thiết kế k&iacute;n v&agrave; bền nhiệt để gi&uacute;p cho việc tiết kiệm được nhi&ecirc;n liệu cũng như thời gian nung gạch. - Người vận h&agrave;ng sẽ th&ocirc;ng qua m&agrave;n h&igrave;nh giao diện SCADA để c&agrave;i đặt, điều chỉnh c&aacute;c th&ocirc;ng số cho ph&ugrave; hợp với từng loại sản phẩm gạch Tuynel cần nung. Điều n&agrave;y l&agrave;m cho qu&aacute; tr&igrave;nh vận h&agrave;nh trở n&ecirc;n dễ d&agrave;ng hơn. H&igrave;nh 2. C&ocirc;ng nghệ sản xuất gạch Tuynel - Thiết kế l&ograve; nung Tuynel theo dạng đường hầm thẳng, hoạt động li&ecirc;n tục. C&aacute;c toa xe go&ograve;ng sẽ chở c&aacute;c sản phẩm nung v&agrave; chuyển động ngược chiều với kh&iacute; n&oacute;ng. - L&ograve; nung được chia l&agrave;m 3 v&ugrave;ng ri&ecirc;ng biệt: v&ugrave;ng đốt n&oacute;ng, v&ugrave;ng l&agrave;m nguội, v&ugrave;ng nung. - Kh&ocirc;ng kh&iacute; lạnh được đốt n&oacute;ng sau khi đ&atilde; l&agrave;m nguội sản phẩm sẽ được chuyển sang v&ugrave;ng nung. H&igrave;nh 3. Sản phẩm gạch Tuynel đang sử dụng rất rộng r&atilde;i hiện nay - Nhờ c&oacute; hệ thống quạt h&uacute;t gi&uacute;p cho kh&iacute; thải của l&ograve; được tho&aacute;t ra ngo&agrave;i. - Nhi&ecirc;n liệu thường được sử dụng l&agrave; dầu FO v&agrave; được nạp qua v&ograve;i phun. Ngo&agrave;i ra, l&ograve; nung c&oacute; thể chuyển sang sử dụng nguy&ecirc;n liệu gas. - C&aacute;c l&ograve; nung gạch Tuynel n&agrave;y c&oacute; chi ph&iacute; lắp đặt cao hơn so với c&aacute;c l&ograve; nung truyền thống trước đ&acirc;y, tuy nhi&ecirc;n ưu điểm của n&oacute; l&agrave; giảm kh&aacute; nhiều chi ph&iacute; điện năng v&agrave; giảm t&aacute;c hại đến với với m&ocirc;i trường. H&igrave;nh 5. Quy tr&igrave;nh sản xuất gạch Tuynel đ&atilde; được cải tiến để giảm chi ph&iacute; - Một l&ograve; nung gạch Tuynel th&ocirc;ng thường c&oacute; k&iacute;ch thước khoảng 94m, l&ograve; sấy c&oacute; chiều d&agrave;i từ 58 đến 62 m, ống kh&oacute;i c&oacute; chiều cao 25m. - Lượng kh&oacute;i thải ra của c&aacute;c l&ograve; gạch Tuynel n&agrave;y kh&aacute; &iacute;t v&agrave; nhiệt độ tầm khoảng từ 40 đến 50oC đến kh&ocirc;ng g&acirc;y ảnh hưởng đến sức khỏe của c&ocirc;ng nh&acirc;n l&agrave;m việc trong l&ograve; nung. Tr&ecirc;n đ&acirc;y l&agrave; một số điểm kh&aacute;i qu&aacute;t về nguy&ecirc;n l&yacute; vận h&agrave;ng cơ bản của một l&ograve; gạch nung Tuynel. Hy vọng sẽ gi&uacute;p bạn đọc c&oacute; thể hiểu một c&aacute;ch kh&aacute;i qu&aacute;t nhất về c&aacute;ch thức hoạt động v&agrave; cơ chế vận h&agrave;nh để tạo ra được sản phẩm gạch Tunel đang được sử dụng kh&aacute; phổ biến trong ng&agrave;nh x&acirc;y dựng của nước ta hiện nay.</p>\r\n', 4, NULL, 'nguyen-ly-van-hanh-lo-tuynel', NULL, 'nguyen-ly-van-hanh-lo-tuynel.jpeg', 0, 1, 0, 0, 0, NULL, 0, NULL, NULL, 16, NULL, NULL, NULL, '', '', '', '2019-11-04 12:53:38', '2021-07-30 00:56:14', 1, 'post', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'Tại sao Gạch Tuynel được ưa chuộng trong xây dựng?', '', '<p>Gạch đất s&eacute;t nung l&agrave; loại gạch được ra đời từ rất l&acirc;u, d&ugrave; vậy, n&oacute; vẫn được ưa chuộng trong x&acirc;y dựng. L&yacute; do v&igrave; sao, ch&uacute;ng ta c&ugrave;ng t&igrave;m hiểu trong phần dưới đ&acirc;y. Với sự ph&aacute;t triển mạnh mẽ của khoa học kỹ thuật, th&igrave; những l&ograve; gạch đất s&eacute;t nung đ&atilde; được thay thể bởi c&ocirc;ng nghệ sản xuất Tuynel. Khiến cho hiệu suất c&ocirc;ng việc trở n&ecirc;n nhanh hơn, đồng thời giữ nguy&ecirc;n được chất lượng sản phẩm. Trong b&agrave;i viết dưới đ&acirc;y, c&ugrave;ng ch&uacute;ng t&ocirc;i t&igrave;m hiểu tại sao gạch Tuynel lại được ưa chuộng trong x&acirc;y dựng. Đồng thời đề xuất cho bạn đọc những l&yacute; do n&ecirc;n sử dụng loại gạch n&agrave;y. Tại sao gạch Tuynel lại được ưa chuộng trong x&acirc;y dựng? 1.C&oacute; gi&aacute; trị thẩm mỹ cao: Ng&agrave;y nay, những c&ocirc;ng tr&igrave;nh x&acirc;y dựng kh&ocirc;ng chỉ c&oacute; c&ocirc;ng dụng để che nắng che mưa như trước, n&oacute; c&ograve;n đem đến gi&aacute; trị thẩm mỹ v&agrave; n&acirc;ng cao chất lượng sống của con người. Ch&iacute;nh v&igrave; vậy, những vật liệu c&oacute; gi&aacute; trị thẩm mỹ cao sẽ được ưa chuộng nhiều hơn. Gạch tuynel với m&agrave;u sắc cực kỳ cổ điển c&ugrave;ng kiểu d&aacute;ng, k&ecirc;t cấu đa dạng lu&ocirc;n đem đến cho kh&aacute;ch h&agrave;ng nhiều sự lựa chọn hơn khi x&acirc;y dựng c&ocirc;ng tr&igrave;nh của m&igrave;nh. Gạch Tuynel 2 Lỗ 2.C&oacute; độ bền l&acirc;u cực kỳ cao: Gach Tuynel được xem l&agrave; loại gạch vĩnh cữu v&agrave; c&oacute; gi&aacute; trị ng&agrave;y c&agrave;ng cao hơn theo thời gian, ch&iacute;nh v&igrave; vậy, d&ugrave; hiện nay c&oacute; rất nhiều loại gạch kh&aacute;c ra đời nhưng gạch tuynel vẫn lu&ocirc;n được ưa chuộng hơn cả. C&oacute; rất nhiều c&ocirc;ng tr&igrave;nh x&acirc;y dựng l&acirc;u đời sử dụng gạch đất s&eacute;t nung, điển h&igrave;nh trong đ&oacute; ch&iacute;nh l&agrave; nh&agrave; thờ Đức B&agrave;, th&agrave;nh phố Hồ Ch&iacute; Minh. Điển h&igrave;nh th&aacute;p ch&agrave;m chăm pa 3.C&oacute; khả năng chống ch&aacute;y cực kỳ tốt: Một trong những ưu điểm kh&aacute;c của gạch Tuynel ch&iacute;nh l&agrave; khả năng chống ch&aacute;y cao, điều n&agrave;y cũng khiến cho nhiều kh&aacute;ch h&agrave;ng ưu ti&ecirc;n lựa chọn loại gạch n&agrave;y hơn trong qu&aacute; tr&igrave;nh x&acirc;y dựng nh&agrave; ở của m&igrave;nh.. Trước t&igrave;nh trạng hỏa hoạn đang ng&agrave;y c&agrave;ng diễn biến phức tạp hơn, th&igrave; những vật liệu c&oacute; khả năng chống ch&aacute;y như gạch Tuynel ch&iacute;nh l&agrave; vật liệu được ưa chuộng nhất. Gạch Tuynel đặc k&eacute;p 150 4.G&oacute;p phần bảo vệ m&ocirc;i trường: Gạch tuynel được sản xuất theo c&ocirc;ng nghệ cực kỳ hiện đại, vừa c&oacute; hiệu suất hoạt động cao, vừa kh&ocirc;ng g&acirc;y hại cho m&ocirc;i trường như những loại gạch kh&aacute;c. Nhờ v&agrave;o ưu điểm n&agrave;y, nhiều người c&oacute; xu hướng ưa chuộng sử dụng gạch Tuynel hơn. C&ocirc;ng nghệ Tuynel g&oacute;p phần bảo vệ m&ocirc;i trường</p>\r\n', 4, NULL, 'tai-sao-gach-tuynel-duoc-ua-chuong-trong-xay-dung', NULL, 'tai-sao-gach-tuynel-duoc-ua-chuong-trong-xay-dung.jpeg', 0, 1, 0, 0, 0, NULL, 0, NULL, NULL, 9, NULL, NULL, NULL, '', '', '', '2019-11-04 12:56:13', '2021-07-28 15:45:06', 1, 'post', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'Lắp đặt dây chuyền công suất 480.0000 viên/ ngày', '<h1><span style=\"color:#FF0000;\"><span style=\"font-size:16px;\">Tập đo&agrave;n Brictec đ&atilde; cũng cấp to&agrave;n bộ d&acirc;y chuyền, thiết bị m&aacute;y m&oacute;c của dự &aacute;n Cosevco - Quảng B&igrave;nh .&nbsp;</span></span></h1>\r\n', '<h2 style=\"font-style:italic;\"><br />\r\nD&acirc;y chuyền hiện đại bậc nhất hiện nay gồm : Hệ cấp liệu băng tải, cấp liệu th&ugrave;ng x&iacute;ch tải , m&aacute;y nghiền b&uacute;a 130x130 nghiền đất đồi c&ocirc;ng suất lớn. M&aacute;y nh&agrave;o trộn 2 trục cỡ lớn. Hệ nh&agrave; ủ liệu sử dụng m&aacute;y x&uacute;c gầu ti&ecirc;n tiến. M&aacute;y nh&agrave;o trộn cao cấp . M&aacute;y nh&agrave;o đ&ugrave;n song cấp &nbsp;ti&ecirc;u chuẩn Ch&acirc;u &Acirc;u với c&ocirc;ng suất lớn v&agrave; lực &eacute;p n&eacute;n tốt cho sản phẩm c&oacute; chất lượng cao. Hệ tự động ho&aacute; với hệ b&agrave;n tổ hợp linh động, sử dụng 2 robot ML 800&nbsp;c&oacute; thể sản xuất nhiều loại sản phẩm c&oacute; chất lượng cao v&agrave; c&oacute; thể xuất khẩu đạt ti&ecirc;u chuẩn Ch&acirc;u &Acirc;u . Hệ l&ograve; nung , l&ograve; sấy được thiết kế đặc biệt v&agrave; kh&aacute;c biệt giảm chi ph&iacute; đầu tư . Đặc biệt l&agrave; tận dụng triệt để hệ kh&iacute; thải l&ograve; nung . C&aacute;ch x&acirc;y đặc biệt để tr&aacute;nh tổn thất nhiệt trong qu&aacute; tr&igrave;nh hoạt động nhằm giảm gi&aacute; th&agrave;nh sản phẩm.&nbsp;<br />\r\nTập đo&agrave;n Brictec rất mong được phục vụ kh&aacute;ch h&agrave;ng tốt nhất . Để được tư vấn chuy&ecirc;n s&acirc;u xin li&ecirc;n hệ hotline : <a href=\"tel:0904284644\">0904284644</a></h2>\r\n', 4, NULL, 'lap-dat-day-chuyen-cong-suat-480-0000-vien-ngay', NULL, 'lap-dat-day-chuyen-cong-suat-480-0000-vien-ngay.jpeg', 0, 1, 0, 0, 0, NULL, 0, NULL, NULL, 13, NULL, NULL, NULL, '', '', '', '2019-11-18 20:17:14', '2021-07-28 15:44:36', 1, 'post', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'dây chuyền nhà máy gạch xây công nghệ cao đi vào hoạt động trong thời điểm Covit 19', '<p>Nh&agrave; m&aacute;y gạch tại Quảng B&igrave;nh&nbsp;đ&atilde;&nbsp;đi v&agrave;o hoạt&nbsp;động trong thời&nbsp;điểm b&ugrave;ng ph&aacute;t dịch Covit 19</p>\r\n\r\n<p>D&ugrave; kh&ocirc;ng c&oacute; chuy&ecirc;n gia nhưng vẫn&nbsp;đưa v&agrave;o nh&agrave; m&aacute;y v&agrave;o hoạt&nbsp;động trong khi c&aacute;c chuy&ecirc;n gia kh&ocirc;ng thể&nbsp;đến&nbsp;được hiện trường.</p>\r\n\r\n<p>Sử dụng c&ocirc;ng nghệ số,&nbsp;điều khiển trực tuyến lắp&nbsp;đặt th&ecirc;m bộ phận&nbsp;điều khiển từ xa. C&aacute;c chuy&ecirc;n gia sẽ&nbsp;ở tại văn ph&ograve;ng nước ngo&agrave;i&nbsp;để&nbsp;điều chỉnh c&aacute;c th&ocirc;ng số.</p>\r\n\r\n<p>Thời&nbsp;đại của c&ocirc;ng nghệ 4.0&nbsp;đ&atilde; ph&aacute;t huy v&agrave;&nbsp;&aacute;p dụng hữu hiệu v&agrave;o dự&nbsp;&aacute;n n&agrave;y.</p>\r\n\r\n<p>Giải ph&aacute;p c&ocirc;ng nghệ l&agrave;&nbsp;điều then chốt, chủ&nbsp;động v&agrave; s&aacute;ng tạo&nbsp;để tạo th&agrave;nh c&ocirc;ng.</p>\r\n\r\n<p>Brictec.vn mong muốn phục vụ kh&aacute;ch h&agrave;ng một c&aacute;ch tốt nhất !</p>\r\n', '<p><img alt=\"\" src=\"/app/webroot/upload/images/0ffb693c0f83ebddb292.jpg\" style=\"width: 1280px; height: 960px;\" /></p>\r\n', 7, NULL, 'day-chuyen-nha-may-gach-xay-cong-nghe-cao-di-vao-hoat-dong-trong-thoi-diem-covit-19', NULL, '-19.jpg', 0, 1, 0, 0, 0, NULL, 0, NULL, NULL, 12, NULL, NULL, NULL, '', '', '', '2020-04-09 10:53:42', '2021-07-28 15:45:24', NULL, 'post', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_products`
--

CREATE TABLE `db_products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` longtext,
  `shortdes` text,
  `khuyenmai` text,
  `thongsokythuat` text,
  `mausac` varchar(100) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `tinhtrang` int(1) DEFAULT '1',
  `mua` int(11) DEFAULT '0',
  `cat_id` int(11) DEFAULT NULL,
  `hang_id` int(11) DEFAULT NULL,
  `quote` text,
  `link` varchar(280) DEFAULT NULL,
  `multiple` text,
  `images` varchar(255) DEFAULT NULL,
  `chatlieu` varchar(255) DEFAULT NULL,
  `hieu` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `thanhphan` varchar(255) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `choose1` int(11) DEFAULT '0',
  `choose2` int(11) DEFAULT '0',
  `choose3` int(11) DEFAULT '0',
  `choose4` int(11) DEFAULT '0',
  `price` int(11) DEFAULT NULL,
  `price2` int(11) DEFAULT NULL,
  `price_trungbay` int(11) DEFAULT NULL,
  `price_nguyenhop` int(11) DEFAULT NULL,
  `sale_off` int(11) DEFAULT NULL,
  `view` int(11) DEFAULT '0',
  `name_eng` varchar(255) DEFAULT NULL,
  `shortdes_eng` text,
  `content_eng` text,
  `title_seo` varchar(500) DEFAULT NULL,
  `meta_key` varchar(500) DEFAULT NULL,
  `meta_des` varchar(500) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id_edit` int(11) DEFAULT NULL,
  `type` varchar(24) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `video` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_products`
--

INSERT INTO `db_products` (`id`, `name`, `content`, `shortdes`, `khuyenmai`, `thongsokythuat`, `mausac`, `code`, `tinhtrang`, `mua`, `cat_id`, `hang_id`, `quote`, `link`, `multiple`, `images`, `chatlieu`, `hieu`, `size`, `thanhphan`, `order`, `user_id`, `choose1`, `choose2`, `choose3`, `choose4`, `price`, `price2`, `price_trungbay`, `price_nguyenhop`, `sale_off`, `view`, `name_eng`, `shortdes_eng`, `content_eng`, `title_seo`, `meta_key`, `meta_des`, `created`, `modified`, `user_id_edit`, `type`, `status`, `video`) VALUES
(1, 'máy đùn', '', '<p>m&aacute;y đ&ugrave;n gạch c&ocirc;ng suất lớn</p>\r\n', NULL, '', NULL, 'd123', 1, 0, 9, NULL, NULL, 'may-dun', NULL, 'may-dun.jpeg', '', '', NULL, '', 0, 1, 1, 0, 0, 0, 20000000, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '', '', '', '2019-10-17 14:44:27', '2021-07-28 15:43:08', 1, 'product', 1, ''),
(2, 'máy nhào lọc', '', '<p>M&aacute;y trộn 2 trục lớn nhất Việt Nam!</p>\r\n', NULL, '', NULL, '0107', 1, 0, 9, NULL, NULL, 'may-nhao-loc', 'du-an-covesco-0.jpeg,du-an-covesco-1.jpeg,du-an-covesco-2.jpeg,du-an-covesco-3.jpeg,du-an-covesco-4.jpeg,du-an-covesco-5.jpeg', 'du-an-covesco.jpeg', '', '', NULL, '', 0, 1, 1, 0, 0, 0, 1000000, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, 'Cung cấp cho dự án Covesco ', '', '', '2019-10-17 15:04:10', '2021-07-28 15:43:33', 1, 'product', 1, ''),
(3, 'Thử nghiệm nguyên liệu', '<pre>\r\nThử nghiệm nguy&ecirc;n liệu</pre>\r\n\r\n<pre>\r\nThử nghiệm nguy&ecirc;n liệu l&agrave; một cơ sở quan trọng cho thiết kế v&agrave; quản l&yacute; chất lượng gạch ng&oacute;i. Th&ocirc;ng qua việc ph&acirc;n t&iacute;ch v&agrave; thử nghiệm nguy&ecirc;n liệu th&ocirc;, chọn quy tr&igrave;nh sản xuất ph&ugrave; hợp để tr&aacute;nh tổn thất đầu tư đ&aacute;ng kể do vấn đề nguy&ecirc;n liệu. Thử nghiệm nguy&ecirc;n liệu bao gồm: ph&acirc;n t&iacute;ch h&oacute;a học, th&agrave;nh phần kho&aacute;ng chất, t&iacute;nh chất vật l&yacute;, t&iacute;nh chất sấy kh&ocirc;, t&iacute;nh chất thi&ecirc;u kết, nổ v&ocirc;i, thử nghiệm đ&oacute;ng băng, v&agrave; tương tự.</pre>\r\n\r\n<pre>\r\n\r\n&nbsp;</pre>\r\n', '<pre>\r\nThử nghiệm nguy&ecirc;n liệu</pre>\r\n', NULL, '', NULL, 'a124', 1, 0, 9, NULL, NULL, 'thu-nghiem-nguyen-lieu', 'thu-nghiem-nguyen-lieu0.jpg,thu-nghiem-nguyen-lieu1.jpg,thu-nghiem-nguyen-lieu2.jpg,thu-nghiem-nguyen-lieu3.jpg', 'thu-nghiem-nguyen-lieu.jpg', '', '', NULL, '', 1, 1, 1, 0, 0, 0, 20000000, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, 'dịch vụ phân tích mẫu đất gạch', 'phân tích mẫu đất gạch', 'phân tích mẫu đất gạch', '2019-11-04 11:53:48', '2020-07-01 00:04:15', 1, 'product', 1, ''),
(4, 'Tư vấn kỹ thuật và thiết kế', '<p>C&ocirc;ng ty đ&atilde; thu&ecirc; kỹ sư kh&ocirc; người &Yacute;, Roberto Rebuzzi (trước đ&acirc;y l&agrave; Piccinini, gi&aacute;m đốc kỹ thuật Morando), kỹ sư l&ograve; Renzo Tunesi (trước đ&acirc;y l&agrave; gi&aacute;m đốc kỹ thuật của LAVAZZETTI SPA), kỹ sư điện Gianni Spagnolo (trước đ&acirc;y l&agrave; tổng gi&aacute;m đốc Cosmec), kỹ sư thủ c&ocirc;ng v&agrave; nhiệt Viện nghi&ecirc;n cứu v&agrave; thiết kế vật liệu tường T&acirc;y An, một kỹ sư cấp cao của gi&aacute;o sư, đ&atilde; tạo ra một đội ngũ kỹ thuật mạnh mẽ kết hợp c&ocirc;ng nghệ ch&acirc;u &Acirc;u v&agrave; c&ocirc;ng nghệ, thiết kế v&agrave; quản l&yacute; địa phương. Cung cấp nghi&ecirc;n cứu trước, tư vấn đầu tư, đề xuất dự &aacute;n v&agrave; chuẩn bị b&aacute;o c&aacute;o nghi&ecirc;n cứu khả thi, thiết kế, hướng dẫn kỹ thuật, gi&aacute;m s&aacute;t v&agrave; k&yacute; kết hợp đồng kỹ thuật cho nh&agrave; m&aacute;y gạch thi&ecirc;u kết.</p>\r\n', '', NULL, '', NULL, '25252', 1, 0, 9, NULL, NULL, 'tu-van-ky-thuat-va-thiet-ke', 'tu-van-ky-thuat-va-thiet-ke0.jpg,tu-van-ky-thuat-va-thiet-ke1.jpg,tu-van-ky-thuat-va-thiet-ke2.jpg', 'tu-van-ky-thuat-va-thiet-ke.jpg', '', '', NULL, '', 2, 1, 1, 0, 0, 0, 50000000, NULL, NULL, NULL, NULL, 6, NULL, NULL, NULL, 'thiết kế nhà máy gạch', 'thiết kế nhà máy gạch', 'thiết kế nhà máy gạch', '2019-11-04 11:57:24', '2021-07-28 15:46:21', NULL, 'product', 1, ''),
(5, 'công nghệ đốt than bột', '<p>m&aacute;y phun đốt than bột cho hầm l&ograve;</p>\r\n', 'máy phun đốt than bột cho hầm lò', NULL, '', NULL, '123', 1, 0, 9, NULL, NULL, 'cong-nghe-dot-than-bot', '', 'cong-nghe-dot-than-bot.jpg', '', '', NULL, '', 3, 1, 1, 0, 0, 0, 10000000, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 'dụng cụ đốt than bột', 'dụng cụ đốt than bột', 'dụng cụ đốt than bột', '2019-11-04 12:35:30', '2021-07-31 15:53:26', NULL, 'product', 1, ''),
(6, 'hệ thống phu dầu', '<p>hệ thống m&aacute;y phu dầu cho l&ograve;</p>\r\n', 'hệ thống máy phu dầu cho lò', NULL, '', NULL, '256', 1, 0, 9, NULL, NULL, 'he-thong-phu-dau', '', 'he-thong-phu-dau.jpg', '', '', NULL, '', 4, 1, 1, 0, 0, 0, 2000000, NULL, NULL, NULL, NULL, 6, NULL, NULL, NULL, 'hệ thống máy phu dầu cho lò', 'hệ thống máy phu dầu cho lò', 'hệ thống máy phu dầu cho lò', '2019-11-04 12:36:36', '2020-07-01 00:04:39', NULL, 'product', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `db_settings`
--

CREATE TABLE `db_settings` (
  `id` int(1) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `address` text,
  `banner` text,
  `footer` text,
  `contactinfo` text,
  `googlemap` text,
  `telephone` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `hotline` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `meta_key` varchar(500) DEFAULT NULL,
  `meta_des` varchar(500) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `google` varchar(255) DEFAULT NULL,
  `tiwter` varchar(255) DEFAULT NULL,
  `youtobe` varchar(255) DEFAULT NULL,
  `v` varchar(255) DEFAULT NULL,
  `in` varchar(255) DEFAULT NULL,
  `cau` varchar(255) DEFAULT NULL,
  `slogan` text,
  `hoidapganday` text,
  `timkiemganday` text,
  `theh1` text,
  `chenthekhac` text,
  `thongtinhotro` text,
  `muabangiaonhan` text,
  `camket` text,
  `tieuchuan` text,
  `video` text,
  `mau1` varchar(50) DEFAULT NULL,
  `mau2` varchar(50) DEFAULT NULL,
  `mau3` varchar(50) DEFAULT NULL,
  `gt1` text,
  `gt2` text,
  `thongbao_h` text,
  `quyche_h` text,
  `diachi_h` text,
  `ns1` varchar(255) DEFAULT NULL,
  `ns2` varchar(255) DEFAULT NULL,
  `ns3` varchar(255) DEFAULT NULL,
  `uudai1` text,
  `uudai2` text,
  `uudai3` text,
  `email1` varchar(255) DEFAULT NULL,
  `email2` varchar(255) DEFAULT NULL,
  `email3` varchar(255) DEFAULT NULL,
  `printerest` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_settings`
--

INSERT INTO `db_settings` (`id`, `name`, `title`, `address`, `banner`, `footer`, `contactinfo`, `googlemap`, `telephone`, `hotline`, `email`, `url`, `meta_key`, `meta_des`, `created`, `modified`, `facebook`, `google`, `tiwter`, `youtobe`, `v`, `in`, `cau`, `slogan`, `hoidapganday`, `timkiemganday`, `theh1`, `chenthekhac`, `thongtinhotro`, `muabangiaonhan`, `camket`, `tieuchuan`, `video`, `mau1`, `mau2`, `mau3`, `gt1`, `gt2`, `thongbao_h`, `quyche_h`, `diachi_h`, `ns1`, `ns2`, `ns3`, `uudai1`, `uudai2`, `uudai3`, `email1`, `email2`, `email3`, `printerest`) VALUES
(1, 'CÔNG TY CỔ PHẦN GIẢI PHÁP CÔNG NGHỆ BRICTEC VIETNAM', 'GIẢI PHÁP CÔNG NGHỆ BRICTEC', '285 Khâm thiên - đống đa', NULL, '<p>C&ocirc;ng ty cổ phần giải ph&aacute;p c&ocirc;ng nghệ Brictec Việt Nam</p>\r\n\r\n<p>Địa chỉ : P 1802 A.3 To&agrave; nh&agrave; EcoLife- 58 Tố Hữu - Nam Từ Li&ecirc;m - H&agrave; Nội</p>\r\n\r\n<p>Điện thoại: <a href=\"tel:0904284644\">0904284644</a><br />\r\n&nbsp;</p>\r\n', '<div>Tại H&Agrave; NỘI :<br />\r\nĐịa chỉ : Số ... Trần Đăng Ninh-Cầu Giấy-H&agrave; Nội<br />\r\nĐiện thoại: 047....<br />\r\nTại Hồ Ch&iacute; Minh :<br />\r\nĐịa chỉ : Chung Cư B&agrave;u C&aacute;t 2 P10 - T&acirc;n B&igrave;nh - HCM<br />\r\nĐiện thoại: Mr. Đạt 0988...</div>\r\n', '<p><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"450\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29793.996973529247!2d105.81945410109321!3d21.02269575409389!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab9bd9861ca1%3A0xe7887f7b72ca17a9!2zSMOgIE7hu5lpLCBIb8OgbiBLaeG6v20sIEjDoCBO4buZaSwgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1456991419208\" style=\"border:0\" width=\"600\"></iframe></p>\r\n', '0904284644', '0904284644', 'duytien123@gmail.com', NULL, 'máy sản xuất gạch', 'máy sản xuất gạch', '2014-09-24 16:19:08', '2019-11-04 11:21:15', 'https://www.facebook.com/duytien.nguyen.71697', '', '#', '', '', '', '', 'XIAOMI - Hệ thống bán lẻ điện thoại xách tay uy tín hàng đầu Việt Nam', 'Đang cập nhật !', '<table align=\"left\" border=\"0\" cellpadding=\"1\" cellspacing=\"1\" dir=\"ltr\" style=\"height: 156px; width: 368px;\">\r\n	<thead>\r\n		<tr>\r\n			<td>\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"font-size: 12px\"><span style=\"color: #696969\"><strong><u><span dir=\"ltr\">Đối với những tỉnh th&agrave;nh kh&aacute;c:</span></u></strong></span></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><em><span style=\"font-size: 12px\"><span style=\"color: #696969\"><span dir=\"ltr\"><span style=\"font-size: 12px\"><span style=\"color: #696969\"><span dir=\"ltr\">Qu&yacute; kh&aacute;ch&nbsp;vui l&ograve;ng thanh to&aacute;n 100% tiền sản phẩm&nbsp;+ &nbsp;ph&iacute; v/c:</span></span></span></span></span></span></em></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\">&nbsp;</div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\">Chủ&nbsp;TK : Đặng Thị&nbsp;Thanh V&acirc;n&nbsp; &nbsp;&nbsp;</span></span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\">&nbsp;</div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\"><u>T&agrave;i khoản&nbsp;1:</u>&nbsp;&nbsp;125.10.00.0252280&nbsp;</span></span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\">Ng&acirc;n h&agrave;ng&nbsp;Đầu Tư&nbsp;&amp; Ph&aacute;t&nbsp;Triển&nbsp;Việt Nam</span></span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\">BIDV&nbsp;</span></span></strong></span></span><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\">&ndash;&nbsp;Chi nh&aacute;nh&nbsp;Đ&ocirc;ng Đ&ocirc; &nbsp; &nbsp;&nbsp;</span></strong></div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\"><u>T&agrave;i khoản&nbsp;</u></span></strong><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\"><u>2:</u>&nbsp;&nbsp;711A 03466745 </span></span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\">Ng&acirc;n h&agrave;ng&nbsp;TMCP C&ocirc;ng Thương Việt&nbsp;Nam</span></span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\">Vietinbank&nbsp;</span></span></strong></span></span><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\">&ndash;</span></strong><span style=\"font-family: tahoma, geneva, sans-serif;\"><span style=\"color:#696969;\"><strong><span dir=\"ltr\">&nbsp;</span></strong></span></span><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\">Chi nh&aacute;nh</span></strong><span style=\"font-family: tahoma, geneva, sans-serif;\"><span style=\"color:#696969;\"><strong><span dir=\"ltr\">&nbsp;Đống Đa</span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\">&nbsp;</div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\"><u>T&agrave;i khoản&nbsp;</u></span></strong><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\"><u>3:</u>&nbsp; 0491 00000 9699 </span></span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\">Ng&acirc;n h&agrave;ng&nbsp;TMCP Ngoại thương Việt&nbsp;Nam</span></span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span style=\"font-size: 12px;\"><span dir=\"ltr\">VCB&nbsp;</span></span></strong></span></span><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\">&ndash;</span></strong><span style=\"font-family: tahoma, geneva, sans-serif;\"><span style=\"color:#696969;\"><strong><span dir=\"ltr\">&nbsp;</span></strong></span></span><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\">Chi nh&aacute;nh</span></strong><span style=\"font-family: tahoma, geneva, sans-serif;\"><span style=\"color:#696969;\"><strong><span dir=\"ltr\">&nbsp;Thăng Long&nbsp;</span></strong></span></span></div>\r\n\r\n			<div style=\"text-align: left; color: blue\">&nbsp;</div>\r\n\r\n			<div style=\"font-family: arial, sans-serif; line-height: 18px;\"><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\"><u>T&agrave;i khoản&nbsp;</u></span></strong><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span dir=\"ltr\"><u>4:</u>&nbsp;98179339</span></strong></span></span></div>\r\n\r\n			<div style=\"font-family: arial, sans-serif; line-height: 18px;\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span dir=\"ltr\">Ng&acirc;n h&agrave;ng&nbsp;TM Cổ Phần &Aacute; Ch&acirc;u&nbsp;</span></strong></span></span><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\">&ndash;&nbsp;</span></strong><span style=\"font-family:tahoma,geneva,sans-serif;\"><span style=\"color:#696969;\"><strong><span dir=\"ltr\">ACB</span></strong></span></span></div>\r\n\r\n			<div style=\"font-family: arial, sans-serif; line-height: 18px;\">&nbsp;</div>\r\n\r\n			<div style=\"font-family: arial, sans-serif; line-height: 18px;\"><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\"><u>T&agrave;i khoản&nbsp;</u></span></strong><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\"><u>5:</u>&nbsp;&nbsp;1303206176062</span></strong></div>\r\n\r\n			<div style=\"color: blue;\"><span style=\"font-family: tahoma, geneva, sans-serif;\"><span style=\"color: rgb(105, 105, 105);\"><strong><span dir=\"ltr\">Ng&acirc;n h&agrave;ng&nbsp;N&ocirc;ng nghiệp&nbsp;&amp; Ph&aacute;t&nbsp;Triển N&ocirc;ng th&ocirc;n&nbsp;Việt Nam Agribank&nbsp;</span></strong></span></span><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\">&ndash;&nbsp;</span></strong><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\">Chi nh&aacute;nh</span></strong><strong style=\"color: rgb(105, 105, 105); font-family: tahoma, geneva, sans-serif;\"><span dir=\"ltr\">&nbsp;H&agrave; Th&agrave;nh &nbsp; &nbsp;&nbsp;</span></strong></div>\r\n			</td>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<div style=\"color: blue\">&nbsp;</div>\r\n\r\n<div style=\"color: blue\">&nbsp;</div>\r\n', 'máy sản xuất gạch', 'máy sản xuất gạch', '<div class=\"f-info	\">\r\n<div class=\"f-timer\">\r\n<p><strong>Thời gian l&agrave;m việc: 8AM - 6PM</strong><br />\r\nHotline: (04) 6 292 3823<br />\r\nHỗ trợ sau b&aacute;n h&agrave;ng: 0912522776</p>\r\n</div>\r\n</div>\r\n', '<div style=\"padding-left:20px; padding-right:20px; padding-top:10px; padding-bottom: 15px; line-height:1.5; font-family:arial; font-size:13px;\">\r\n<div style=\"padding-bottom:5px\">\r\n<ul>\r\n	<li><strong>Thời Trang 360</strong>&nbsp;chỉ b&aacute;n h&agrave;ng Online v&agrave; giao sản phẩm trực tiếp tới tận tay kh&aacute;ch h&agrave;ng.</li>\r\n</ul>\r\n</div>\r\n\r\n<div style=\"padding-bottom:5px\">\r\n<ul>\r\n	<li>Qu&yacute; kh&aacute;ch vui l&ograve;ng Đặt mua tr&ecirc;n website hoặc gọi điện trực tiếp cho ch&uacute;ng t&ocirc;i,&nbsp;<strong>Thời Trang 360</strong>&nbsp;sẽ giao h&agrave;ng đến địa chỉ m&agrave; kh&aacute;ch h&agrave;ng đ&atilde; đăng k&iacute;.</li>\r\n</ul>\r\n</div>\r\n\r\n<div style=\"padding-bottom:5px\">\r\n<ul>\r\n	<li>Mức ph&iacute; vận chuyển: Miễn ph&iacute; vận chuyển to&agrave;n quốc.</li>\r\n	<li>Qu&yacute; kh&aacute;ch được kiểm tra kỹ sản phẩm trước khi nhận h&agrave;ng v&agrave; thanh to&aacute;n tiền. H&agrave;ng đ&atilde; mua xin miễn đổi trả.</li>\r\n</ul>\r\n</div>\r\n\r\n<div style=\"padding-bottom:5px\">\r\n<ul>\r\n	<li>Thời gian nhận h&agrave;ng t&iacute;nh từ thời điểm <strong>Thời Trang 360</strong> gọi điện x&aacute;c nhận đơn h&agrave;ng, kh&aacute;ch h&agrave;ng ở nội th&agrave;nh H&agrave; Nội sẽ nhận được h&agrave;ng <strong>trong ng&agrave;y</strong>, kh&aacute;ch h&agrave;ng ở c&aacute;c th&agrave;nh phố lớn kh&aacute;c nhận h&agrave;ng sau <strong>1 - 2 ng&agrave;y</strong>, kh&aacute;ch h&agrave;ng ở c&aacute;c Huyện, X&atilde; nhận h&agrave;ng từ <strong>3 - 5 ng&agrave;y</strong>.</li>\r\n</ul>\r\n</div>\r\n</div>\r\n', '<div style=\" font-size: 13px; margin-bottom: 7px; text-align: justify; line-height: 1.2; color: #000000\"><strong>&bull; Thời trang 360</strong> cam kết kh&ocirc;ng b&aacute;n sản phẩm k&eacute;m chất lượng gi&aacute; cả lu&ocirc;n tốt nhất thị trường, tất cả h&igrave;nh ảnh thắt lưng, v&iacute; da... đều l&agrave; do ch&uacute;ng t&ocirc;i tự chụp từ ch&iacute;nh sản phẩm thật, c&aacute;c bạn sẽ mua được ch&iacute;nh x&aacute;c những g&igrave; bạn đang xem.</div>\r\n\r\n<div style=\"font-size: 13px; margin-bottom: 7px; text-align: justify; line-height: 1.2; color: #000000\"><strong>&bull;</strong> Ch&uacute;ng t&ocirc;i mong muốn mang đến cho bạn một sự h&agrave;i l&ograve;ng nhất c&oacute; thể với phương ch&acirc;m coi kh&aacute;ch h&agrave;ng l&agrave; thượng đế, đặt quyền lợi của kh&aacute;ch h&agrave;ng l&ecirc;n tr&ecirc;n hết.</div>\r\n', '+ G&oacute;i Tiết kiệm +200.000đ (BH 03 Th&aacute;ng phần cứng)<br />\r\n+ G&oacute;i Ti&ecirc;u Chuẩn +500.000đ (BH 12 Th&aacute;ng phần cứng)<br />\r\n​+ G&oacute;i Bảo h&agrave;nh V&agrave;ng + 990.000đ (12 Th&aacute;ng bao gồm cả nguồn v&agrave; M&agrave;n H&igrave;nh)', '<iframe src=\"https://www.youtube.com/embed/VVoBIX6eI3o\" frameborder=\"0\" width=\"251\" height=\"181\" allowfullscreen></iframe>', '0C62E4', 'F4F4F4', '0C62E4', '<div>Chuy&ecirc;n khoa chữa trị c&aacute;c bệnh hậu m&ocirc;n trực tr&agrave;ng của ph&ograve;ng kh&aacute;m đa khoa Thi&ecirc;n T&acirc;m hiện nay đang đưa v&agrave;o sử dụng c&aacute;c kĩ thuật x&acirc;m lấn tối thiểu chữa trị bệnh trĩ một c&aacute;ch chuy&ecirc;n nghiệp, kh&ocirc;ng cần mổ.<br />\r\n&nbsp; &nbsp;Điều trị&nbsp;<a href=\"http://phongkhamthientam.net/Benh-Tri/\" target=\"_blank\" title=\"Bệnh Trĩ\">Bệnh Trĩ</a>&nbsp;kh&ocirc;ng cần d&ugrave;ng dao mổ l&agrave; phương ph&aacute;p kết hợp kiểm tra v&agrave; điều trị, hiệu quả cao, tiện lợi, an to&agrave;n, kh&ocirc;ng đau, vết thương nhỏ, thời gian điều trị ngắn&hellip; Phương ph&aacute;p n&agrave;y căn cứ v&agrave;o s&oacute;ng si&ecirc;u thanh m&agrave; đầu d&ograve; ph&aacute;t ra v&agrave; tiếp nhận để x&aacute;c định vị tr&iacute; động mạch b&uacute;i trĩ, đồng thời th&ocirc;ng qua lỗ đoạn tr&ecirc;n của đầu d&ograve; tiến h&agrave;nh thắt động mạch tr&ecirc;n nếp gấp hậu m&ocirc;n. Đặc điểm của n&oacute; l&agrave; định vị ch&iacute;nh x&aacute;c, nhanh ch&oacute;ng, vết thương nhỏ.<br />\r\n&nbsp; Thời gian tiểu phẫu Bệnh Trĩ thường chỉ khoảng từ 15-30 ph&uacute;t. 100% người bệnh mất c&aacute;c triệu chứng như chảy m&aacute;u hậu m&ocirc;n hay sa b&uacute;i trĩ. Sau tiểu phẫu 98% người bệnh h&agrave;i l&ograve;ng với kết quả điều trị, kh&ocirc;ng c&ograve;n c&aacute;c triệu chứng trước tiểu phẫu như chảy m&aacute;u, sa b&uacute;i trĩ, ướt hậu m&ocirc;n&hellip; Do khả năng biến chứng sau tiểu phẫu n&agrave;y tương đối nhỏ n&ecirc;n ho&agrave;n to&agrave;n kh&ocirc;ng cần nằm viện&hellip;</div>\r\n', '<p><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"315\" src=\"https://www.youtube.com/embed/qtH7jLgj22o\" width=\"420\"></iframe><br />\r\n​<span style=\"color: rgb(0, 0, 0); font-family: tahoma; font-size: 12px; line-height: 20px;\">Phương ch&acirc;m chữa trị bệnh trĩ của ch&uacute;ng t&ocirc;i l&agrave; giảm thiểu đến mức tối đa sự đau đớn cho người bệnh, ngăn ngừa t&aacute;i ph&aacute;t.</span></p>\r\n', '<p>Trung t&acirc;m cung ứng nh&acirc;n lực cho ng&agrave;nh &ocirc; t&ocirc;KAS centerđược th&agrave;nh lập tr&ecirc;n cơ sở quan s&aacute;t, trao đổi với c&aacute;c đại l&yacute; &ocirc; t&ocirc; ở H&agrave; Nội cũng như 1 số đại l&yacute; &ocirc; t&ocirc; tr&ecirc;n khu vực miền bắc, c&ugrave;ngti&ecirc;u ch&iacute; đảm bảo về đầu ra việc l&agrave;m với những sinh vi&ecirc;n đăng k&iacute; học tại trung t&acirc;m.</p>\r\n\r\n<p><strong>KAS centervới c&aacute;c kh&oacute;a học nhằm bổ sung kỹ năng c&ograve;n thiếu của sinh vi&ecirc;n trước v&agrave; sau khi ra trường, cụ thể:</strong></p>\r\n\r\n<p>1.&nbsp;&nbsp;&nbsp;&nbsp; Tiếng Anh chuy&ecirc;n ng&agrave;nh &ocirc; t&ocirc;<br />\r\n2.&nbsp;&nbsp;&nbsp;&nbsp; Kỹ năng Sale&amp;Marketing<br />\r\n3.&nbsp;&nbsp;&nbsp;&nbsp; Kỹ thuật vi&ecirc;n điện, gầm, đồng sơn</p>\r\n\r\n<p><strong>KAS centercam kết:</strong></p>\r\n\r\n<p>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Đảm bảo về chất lượng dạy v&agrave; học của sinh vi&ecirc;n<br />\r\n2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cung cấp đầu ra cho sinh vi&ecirc;n sau khi học xong kh&oacute;a học</p>\r\n\r\n<p>Trước cơ hội ph&aacute;t triển của ng&agrave;nh &ocirc; t&ocirc; hiện nay, khi năm 2018 khi hiệp định thương mại h&oacute;a ASEAN&nbsp; (ATIGA) ch&iacute;nh thức c&oacute; hiệu lực với thuế nhập khẩu xe hơi từ c&aacute;c nước ASEAN c&ograve;n 0%. H&agrave;ng loạt c&aacute;c c&ocirc;ng ty &ocirc; t&ocirc; lớn tr&ecirc;n thế giới đ&atilde; v&agrave; đang đồng loạt đầu tư v&agrave;o Việt Nam (1 trong những thị trường c&oacute; tiềm năng&nbsp; ph&aacute;t triển nhất trong khu vực ASEAN),&nbsp;KAS Center&nbsp;l&agrave; sự lựa chọn kh&ocirc;ng thể thiếu để c&aacute;c bạn sinh vi&ecirc;n sắp ra trường, c&aacute;c bạn sinh vi&ecirc;n mới ra trường ho&agrave;n thiện kỹ năng để trở th&agrave;nh một &ldquo;d&acirc;n &ocirc; t&ocirc;&rdquo; ch&iacute;nh hiệu.​​</p>\r\n', '', '<div style=\"text-align: center;\"><strong>Địa chỉ nhận h&agrave;ng tại Bằng Tường</strong><br />\r\n&nbsp;<br />\r\n广西&nbsp;/&nbsp;崇左&nbsp;/&nbsp;凭祥&nbsp;/&nbsp;广西凭祥综合保税区<br />\r\n详细地址:&nbsp;南大路西--广越物流园对面--佳旺小区2栋1楼&nbsp;金马物流仓库,在广明物流附近<br />\r\n邮政编码: 523600<br />\r\n收货人姓名: m&atilde; số kh&aacute;ch h&agrave;ng &nbsp;&nbsp;宋明友<br />\r\n手机号码&nbsp;: 13297809290<br />\r\n&nbsp;<br />\r\n<strong>Địa chỉ kho Quảng Ch&acirc;u</strong><br />\r\n广州市白云区增槎路1133号西盈物流9档；<br />\r\n收货人姓名: m&atilde; số kh&aacute;ch h&agrave;ng &nbsp;&nbsp;宋明友<br />\r\n宋明友收:&nbsp;18664522722<br />\r\n邮政编码：510000<br />\r\nĐề nghịkh&aacute;ch h&agrave;ng ghi ch&uacute; th&ecirc;m c&acirc;u n&agrave;y ph&iacute;a dưới cho shop biết:<br />\r\n此电话号码是代收人号码，非买家。请卖家不联系<br />\r\n(Số điện thoại n&agrave;y l&agrave; số điện thoạicủa người nhận h&agrave;ng hộ, kh&ocirc;ng phải l&agrave; b&ecirc;n mua h&agrave;ng, đề nghị shop kh&ocirc;ng li&ecirc;nhệ.)</div>\r\n', 'Giới thiệu về công ty', '', 'Địa chỉ nhận hàng bên Trung Quốc', '<ol>\r\n	<li style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-family: Roboto; font-size: 14px;\">Ship&nbsp;nội th&agrave;nh H&agrave; Nội - Giao h&agrave;ng sau 60&quot;.</li>\r\n	<li style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-family: Roboto; font-size: 14px;\">Ship&nbsp;to&agrave;n quốc</li>\r\n</ol>\r\n', '<ol>\r\n	<li style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-family: Roboto; font-size: 14px;\">Đổi miễn ph&iacute;&nbsp;trong 30 ng&agrave;y đầu ti&ecirc;n sử dụng.</li>\r\n	<li style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-family: Roboto; font-size: 14px;\">Bảo H&agrave;nh V&agrave;ng:&nbsp;Bảo h&agrave;nh 15 th&aacute;ng&nbsp; ( Gồm: Phần cứng, nguồn, m&agrave;n h&igrave;nh, cảm ứng...) + Đổi mới miễn ph&iacute; trong 06 th&aacute;ng&nbsp;đầu ti&ecirc;n sử dụng nếu lỗi do nh&agrave; sản xuất.</li>\r\n	<li style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(34, 34, 34); font-family: Roboto; font-size: 14px;\">Bảo tr&igrave;&nbsp;phần mềm hỗ trợ trọn đời.</li>\r\n</ol>\r\n', '<ol>\r\n	<li>Tivi mới 100% ch&iacute;nh h&atilde;ng</li>\r\n	<li>Đổi miễn ph&iacute; trong 30 ng&agrave;y đầu ti&ecirc;n khi sử dụng.</li>\r\n	<li>Bảo H&agrave;nh V&agrave;ng:&nbsp;Bảo h&agrave;nh 15 th&aacute;ng&nbsp; ( Gồm: Phần cứng, nguồn, m&agrave;n h&igrave;nh, cảm ứng...) + Đổi mới miễn ph&iacute; trong 06 th&aacute;ng&nbsp;đầu ti&ecirc;n sử dụng nếu lỗi do nh&agrave; sản xuất.</li>\r\n	<li>Kiểm tra thoải m&aacute;i trước khi mua h&agrave;ng.</li>\r\n	<li>QUAY VIDEO&nbsp;CHO KH&Aacute;CH H&Agrave;NG Ở XA.</li>\r\n	<li>Cam kết h&agrave;i l&ograve;ng kh&aacute;ch h&agrave;ng.</li>\r\n</ol>\r\n', 'duytien123 @gmail.com', 'duytien123 @gmail.com', 'duytien123@gmail.com', '#');

-- --------------------------------------------------------

--
-- Table structure for table `db_slideshows`
--

CREATE TABLE `db_slideshows` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  `content` text,
  `url` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `type` varchar(24) DEFAULT NULL,
  `order` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_slideshows`
--

INSERT INTO `db_slideshows` (`id`, `name`, `images`, `content`, `url`, `created`, `modified`, `status`, `type`, `order`) VALUES
(1, '#', '.jpeg', NULL, '#', '2021-07-31 11:30:04', '2021-07-31 11:30:04', 1, NULL, NULL),
(2, '#', '-2.jpeg', NULL, '#', '2021-07-31 11:30:14', '2021-07-31 11:30:14', 1, NULL, NULL),
(3, '#', '-3.jpeg', NULL, '#', '2021-07-31 11:30:24', '2021-07-31 11:30:24', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_supports`
--

CREATE TABLE `db_supports` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `phone1` varchar(255) DEFAULT NULL,
  `phone2` varchar(255) DEFAULT NULL,
  `yahoo` varchar(255) DEFAULT NULL,
  `yahoo1` varchar(255) DEFAULT NULL,
  `yahoo2` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `name2` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_supports`
--

INSERT INTO `db_supports` (`id`, `name`, `phone`, `phone1`, `phone2`, `yahoo`, `yahoo1`, `yahoo2`, `email`, `skype`, `created`, `modified`, `status`, `name2`, `images`) VALUES
(5, 'Mai Thu Huyền', '0985 ...', NULL, NULL, '', NULL, NULL, 'abc@gmail.com', 'abc', '2016-02-26 08:28:05', '2017-02-09 12:59:03', 1, NULL, NULL),
(7, 'Mr Thành', '098 ...', NULL, NULL, '', NULL, NULL, 'abc@gmail.com', 'skype', '2017-02-09 12:59:21', '2017-02-09 12:59:21', 1, NULL, NULL),
(8, 'Mr Thành', '098 ...', NULL, NULL, '', NULL, NULL, 'abc@gmail.com', 'skype', '2017-02-09 12:59:26', '2017-02-09 12:59:26', 1, NULL, NULL),
(9, 'Mr. Nam', '098 ...', NULL, NULL, '', NULL, NULL, 'abc@gmail.com', 'skype', '2017-02-09 12:59:31', '2017-02-09 12:59:31', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_tinhthanhs`
--

CREATE TABLE `db_tinhthanhs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `order` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `db_users`
--

CREATE TABLE `db_users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(80) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `telephone` varchar(30) DEFAULT NULL,
  `birth_date` varchar(200) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `images` varchar(256) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `active_key` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `address` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `city_tinh` varchar(255) NOT NULL,
  `quocgia` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `vip` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_users`
--

INSERT INTO `db_users` (`id`, `fullname`, `username`, `password`, `name`, `email`, `phone`, `telephone`, `birth_date`, `sex`, `images`, `created`, `modified`, `active_key`, `status`, `address`, `address1`, `city_tinh`, `quocgia`, `type`, `vip`) VALUES
(1, 'check12', 'check12', 'e51683d2dbcc88163150b51c8c0bc18b', NULL, 'check12@gmail.com', '2341231', '', NULL, NULL, NULL, '2016-06-27 13:46:10', '2016-06-27 13:48:20', NULL, 1, 'check12', '', '', '', '', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `db_videos`
--

CREATE TABLE `db_videos` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_id_edit` int(11) DEFAULT NULL,
  `video` text,
  `view` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `order` int(11) DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `title_seo` varchar(500) DEFAULT NULL,
  `meta_key` varchar(500) DEFAULT NULL,
  `meta_des` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_videos`
--

INSERT INTO `db_videos` (`id`, `name`, `link`, `cat_id`, `user_id`, `user_id_edit`, `video`, `view`, `status`, `order`, `created`, `modified`, `lft`, `rght`, `type`, `title_seo`, `meta_key`, `meta_des`) VALUES
(1, 'Video để đời của Công Phượng trận U19 Việt Nam Gặp U19 Úc', 'video-de-doi-cua-cong-phuong-tran-u19-viet-nam-gap-u19-uc', 31, NULL, NULL, 'https://www.youtube.com/watch?v=yNtSkyemtQs', 1, 1, 0, '2014-12-08 15:05:46', '2014-12-09 13:27:09', NULL, NULL, 'video', NULL, NULL, NULL),
(2, 'U19 Viet Nam 5-1 U19 Hong Kong (China)', 'u19-viet-nam-5-1-u19-hong-kong-china', 31, NULL, NULL, 'https://www.youtube.com/watch?v=MrIdiOLc3l0', 1, 1, 1, '2014-12-08 15:07:06', '2014-12-09 13:36:32', NULL, NULL, 'video', NULL, NULL, NULL),
(3, 'Nguyễn Công Phượng ghi bàn thắng quyết định U19 VN-AUS', 'nguyen-cong-phuong-ghi-ban-thang-quyet-dinh-u19-vn-aus', 31, NULL, NULL, 'https://www.youtube.com/watch?v=QcXLNbRDFfc', NULL, 1, 2, '2014-12-08 15:07:23', '2014-12-09 09:30:05', NULL, NULL, 'video', NULL, NULL, NULL),
(4, 'Nguyễn Công Phượng - 1 phút làm nên người hùng', 'nguyen-cong-phuong-1-phut-lam-nen-nguoi-hung', 31, NULL, NULL, 'https://www.youtube.com/watch?v=nWqxHviH5o4', NULL, 1, 3, '2014-12-08 15:07:40', '2014-12-09 09:30:08', NULL, NULL, 'video', NULL, NULL, NULL),
(5, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-21', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-08 15:52:01', '2014-12-09 09:30:11', NULL, NULL, 'video', NULL, NULL, NULL),
(6, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-22', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-08 15:55:39', '2014-12-09 09:30:15', NULL, NULL, 'video', NULL, NULL, NULL),
(7, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-23', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-08 15:56:00', '2014-12-09 09:30:18', NULL, NULL, 'video', NULL, NULL, NULL),
(8, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-24', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-08 15:56:03', '2014-12-09 09:30:21', NULL, NULL, 'video', NULL, NULL, NULL),
(9, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-25', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-08 15:56:06', '2014-12-09 09:30:24', NULL, NULL, 'video', NULL, NULL, NULL),
(10, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-26', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-08 15:56:11', '2014-12-09 09:30:26', NULL, NULL, 'video', NULL, NULL, NULL),
(11, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:26:04', '2014-12-09 09:26:04', NULL, NULL, 'video', NULL, NULL, NULL),
(12, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-2', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:26:54', '2014-12-09 09:26:54', NULL, NULL, 'video', NULL, NULL, NULL),
(13, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-3', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:27:38', '2014-12-09 09:27:38', NULL, NULL, 'video', NULL, NULL, NULL),
(14, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-4', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:27:42', '2014-12-09 09:27:42', NULL, NULL, 'video', NULL, NULL, NULL),
(15, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-5', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:27:45', '2014-12-09 09:27:45', NULL, NULL, 'video', NULL, NULL, NULL),
(16, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-6', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:27:49', '2014-12-09 09:27:49', NULL, NULL, 'video', NULL, NULL, NULL),
(17, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-7', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:27:52', '2014-12-09 09:27:52', NULL, NULL, 'video', NULL, NULL, NULL),
(18, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-8', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:27:56', '2014-12-09 09:27:56', NULL, NULL, 'video', NULL, NULL, NULL),
(19, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-9', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:27:59', '2014-12-09 09:27:59', NULL, NULL, 'video', NULL, NULL, NULL),
(20, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-10', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:03', '2014-12-09 09:28:03', NULL, NULL, 'video', NULL, NULL, NULL),
(21, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-11', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:11', '2014-12-09 09:28:11', NULL, NULL, 'video', NULL, NULL, NULL),
(22, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-12', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:13', '2014-12-09 09:28:13', NULL, NULL, 'video', NULL, NULL, NULL),
(23, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-13', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:15', '2014-12-09 09:28:15', NULL, NULL, 'video', NULL, NULL, NULL),
(24, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-14', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:18', '2014-12-09 09:28:18', NULL, NULL, 'video', NULL, NULL, NULL),
(25, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-15', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:20', '2014-12-09 09:28:20', NULL, NULL, 'video', NULL, NULL, NULL),
(26, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-16', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:22', '2014-12-09 09:28:22', NULL, NULL, 'video', NULL, NULL, NULL),
(27, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-17', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:27', '2014-12-09 09:28:27', NULL, NULL, 'video', NULL, NULL, NULL),
(28, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-18', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:30', '2014-12-09 09:28:30', NULL, NULL, 'video', NULL, NULL, NULL),
(29, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-19', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', NULL, 1, 4, '2014-12-09 09:28:33', '2014-12-09 09:28:33', NULL, NULL, 'video', NULL, NULL, NULL),
(30, 'Cười vỡ bụng với quảng cáo thái lan', 'cuoi-vo-bung-voi-quang-cao-thai-lan-20', 26, NULL, NULL, 'https://www.youtube.com/watch?v=HrbA67NKdcg', 1, 1, 4, '2014-12-09 09:28:37', '2014-12-09 13:41:50', NULL, NULL, 'video', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `db_accounts`
--
ALTER TABLE `db_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_addimgs`
--
ALTER TABLE `db_addimgs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_catalogues`
--
ALTER TABLE `db_catalogues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_catproducts`
--
ALTER TABLE `db_catproducts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_emaildks`
--
ALTER TABLE `db_emaildks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_extentions`
--
ALTER TABLE `db_extentions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_exttmps`
--
ALTER TABLE `db_exttmps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_groups`
--
ALTER TABLE `db_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_hangs`
--
ALTER TABLE `db_hangs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_infocustomers`
--
ALTER TABLE `db_infocustomers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_kiemchuyen`
--
ALTER TABLE `db_kiemchuyen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_orders`
--
ALTER TABLE `db_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_pages`
--
ALTER TABLE `db_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_permisions`
--
ALTER TABLE `db_permisions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_posts`
--
ALTER TABLE `db_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_products`
--
ALTER TABLE `db_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_settings`
--
ALTER TABLE `db_settings`
  ADD PRIMARY KEY (`id`,`telephone`);

--
-- Indexes for table `db_slideshows`
--
ALTER TABLE `db_slideshows`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_supports`
--
ALTER TABLE `db_supports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_tinhthanhs`
--
ALTER TABLE `db_tinhthanhs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_users`
--
ALTER TABLE `db_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_videos`
--
ALTER TABLE `db_videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `db_accounts`
--
ALTER TABLE `db_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_addimgs`
--
ALTER TABLE `db_addimgs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `db_catalogues`
--
ALTER TABLE `db_catalogues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_catproducts`
--
ALTER TABLE `db_catproducts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `db_emaildks`
--
ALTER TABLE `db_emaildks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_extentions`
--
ALTER TABLE `db_extentions`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `db_exttmps`
--
ALTER TABLE `db_exttmps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `db_groups`
--
ALTER TABLE `db_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_hangs`
--
ALTER TABLE `db_hangs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `db_infocustomers`
--
ALTER TABLE `db_infocustomers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_kiemchuyen`
--
ALTER TABLE `db_kiemchuyen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_orders`
--
ALTER TABLE `db_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_pages`
--
ALTER TABLE `db_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_permisions`
--
ALTER TABLE `db_permisions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `db_posts`
--
ALTER TABLE `db_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `db_products`
--
ALTER TABLE `db_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `db_settings`
--
ALTER TABLE `db_settings`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_slideshows`
--
ALTER TABLE `db_slideshows`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `db_supports`
--
ALTER TABLE `db_supports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `db_tinhthanhs`
--
ALTER TABLE `db_tinhthanhs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_users`
--
ALTER TABLE `db_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_videos`
--
ALTER TABLE `db_videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
